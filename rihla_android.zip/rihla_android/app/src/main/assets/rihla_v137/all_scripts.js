

/* ===== مفاتيح التاريخ المحلي ===== */
let activeLocalDateKey = getLocalDateKey();
function getLocalDateKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function daysBetweenLocalKeys(keyA, keyB) {
  const [ya, ma, da] = keyA.split('-').map(Number);
  const [yb, mb, db] = keyB.split('-').map(Number);
  const a = new Date(ya, ma - 1, da);
  const b = new Date(yb, mb - 1, db);
  return Math.round((b - a) / 86400000);
}

function getYesterdayKey() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return getLocalDateKey(d);
}

const DAILY_TARGET = 3;
function computeStreak(dailyLog, todayKey) {
  const completedDays = Object.keys(dailyLog || {})
    .filter(k => (dailyLog[k]?.tasksDone ?? 0) >= DAILY_TARGET)
    .sort();
  if (!completedDays.length) return { current: 0, best: 0 };
  let best = 1, run = 1;
  for (let i = 1; i < completedDays.length; i++) {
    run = daysBetweenLocalKeys(completedDays[i - 1], completedDays[i]) === 1 ? run + 1 : 1;
    if (run > best) best = run;
  }
  const lastDay = completedDays[completedDays.length - 1];
  const gapFromToday = daysBetweenLocalKeys(lastDay, todayKey);
  let current = 0;
  if (gapFromToday === 0 || gapFromToday === 1) {
    current = 1;
    for (let i = completedDays.length - 1; i > 0; i--) {
      if (daysBetweenLocalKeys(completedDays[i - 1], completedDays[i]) === 1) current++;
      else break;
    }
  }
  return { current, best };
}

function getDailyTaskLog() {
  const log = {};
  const prefix = 'rihlati_tasks_';
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (!key || !key.startsWith(prefix)) continue;
    const dateKey = key.slice(prefix.length);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) continue;
    let dayTasks = [];
    try { dayTasks = JSON.parse(localStorage.getItem(key) || '[]'); } catch (e) {}
    log[dateKey] = { tasksDone: Array.isArray(dayTasks) ? dayTasks.filter(t => t && t.done).length : 0 };
  }
  return log;
}

/* ===== تأملاتي وخواطري ===== */
const NOTES_STORAGE_KEY = 'rihlati_notes';
function getNotes(){
  try {
    const value = JSON.parse(localStorage.getItem(NOTES_STORAGE_KEY) || '[]');
    return Array.isArray(value) ? value.filter(n => n && typeof n.text === 'string') : [];
  } catch(e) { return []; }
}
function renderNotes(){
  const list = document.getElementById('notesList');
  if(!list) return;
  const notes = getNotes();
  list.replaceChildren();
  if(!notes.length){
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = 'لا توجد ملاحظات بعد. اكتب أول تأمل لك اليوم 🌿';
    list.appendChild(empty);
    return;
  }
  notes.forEach(note => {
    const card = document.createElement('div');
    card.className = 'note-card';
    const date = document.createElement('div');
    date.className = 'note-date';
    const parsed = new Date(note.date);
    date.textContent = Number.isNaN(parsed.getTime()) ? 'ملاحظة محفوظة' : parsed.toLocaleString('ar-EG');
    const body = document.createElement('div');
    body.className = 'note-text';
    body.textContent = note.text;
    const del = document.createElement('button');
    del.className = 'note-del';
    del.type = 'button';
    del.textContent = '🗑';
    del.setAttribute('aria-label','حذف الملاحظة');
    del.addEventListener('click', () => deleteNote(note.id));
    card.append(del,date,body);
    list.appendChild(card);
  });
}
function addNote(){
  const input = document.getElementById('noteInput');
  if(!input) return;
  const text = input.value.trim();
  if(!text){ alert('اكتب الملاحظة أولاً'); input.focus(); return; }
  const notes = getNotes();
  notes.unshift({id: (Date.now().toString(36) + Math.random().toString(36).slice(2,7)), text, date: new Date().toISOString()});
  try {
    localStorage.setItem(NOTES_STORAGE_KEY, JSON.stringify(notes));
    input.value = '';
    renderNotes();
  } catch(e) { alert('تعذر حفظ الملاحظة. قد تكون مساحة التخزين ممتلئة.'); }
}
function deleteNote(id){
  if(!confirm('هل تريد حذف هذه الملاحظة؟')) return;
  const notes = getNotes().filter(note => note.id !== id);
  try { localStorage.setItem(NOTES_STORAGE_KEY, JSON.stringify(notes)); renderNotes(); }
  catch(e) { alert('تعذر تحديث الملاحظات.'); }
}

/* ===== الإعدادات ===== */
let settings = JSON.parse(localStorage.getItem('rihlati_settings') || '{"calcMethod":"5","notifications":false,"prePrayerReminder":false,"darkMode":false,"adhanSound":"makkah"}');
if(typeof settings.prePrayerReminder !== 'boolean') settings.prePrayerReminder = false;
if(!settings.adhanSound) settings.adhanSound = 'makkah';

/* ===== أصوات الأذان ===== */
const ADHAN_SOUNDS = [
  {id:'makkah', name:'أذان الحرم المكي', url:'https://www.islamcan.com/audio/adhan/azan1.mp3'},
  {id:'madinah', name:'أذان المسجد النبوي', url:'https://www.islamcan.com/audio/adhan/azan2.mp3'},
  {id:'egypt', name:'أذان مصري', url:'https://www.islamcan.com/audio/adhan/azan3.mp3'},
  {id:'abdulbasit', name:'أذان عبد الباسط', url:'https://www.islamcan.com/audio/adhan/azan8.mp3'},
  {id:'afasy', name:'أذان مشاري العفاسي', url:'https://www.islamcan.com/audio/adhan/azan11.mp3'}
];
let previewAudio = null;
function initAdhanSounds(){
  const sel = document.getElementById('adhanSoundSelect');
  if(!sel) return;
  sel.innerHTML = '';
  ADHAN_SOUNDS.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.id;
    opt.textContent = s.name;
    if(s.id === settings.adhanSound) opt.selected = true;
    sel.appendChild(opt);
  });
}
function changeAdhanSound(){
  settings.adhanSound = document.getElementById('adhanSoundSelect').value;
  localStorage.setItem('rihlati_settings', JSON.stringify(settings));
}
function previewAdhan(){
  if(previewAudio){ previewAudio.pause(); previewAudio = null; }
  const sound = ADHAN_SOUNDS.find(s => s.id === settings.adhanSound);
  if(!sound) return;
  previewAudio = new Audio(sound.url);
  previewAudio.play().catch(() => alert('تعذر تشغيل الصوت'));
}

/* ===== المشاركة ===== */
async function shareText(text, title){
  if(navigator.share){
    try{ await navigator.share({title: title || 'رحلتي', text: text}); }catch(e){}
  } else {
    try{
      await navigator.clipboard.writeText(text);
      alert('✅ تم النسخ — الصقه في أي مكان');
    }catch(e){ alert('تعذر المشاركة'); }
  }
}

/* ===== التنقل بين الشاشات ===== */
function goTo(screenId){
  document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.screen === screenId));
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById('screen-' + screenId);
  if(el) {
    el.classList.add('active');
    const rights = document.querySelector('.brand-rights');
    if(rights) el.appendChild(rights);
  }
  window.scrollTo({top:0,behavior:'smooth'});
  if(screenId === 'ibadat') initIbadat();
  if(screenId === 'gharsa'){ renderTasks(); updateTreeSummary(); }
  if(screenId === 'achievements') renderStats();
  if(screenId === 'journey'){ renderHistory(); renderMonthlyStats(); renderNotes(); }
}

function switchIbadat(name){
  document.querySelectorAll('#screen-ibadat .sub-tab').forEach(t => t.classList.remove('active'));
  const tab = document.querySelector(`#screen-ibadat .sub-tab[onclick="switchIbadat('${name}')"]`);
  if(tab) tab.classList.add('active');
  document.querySelectorAll('#screen-ibadat .sub-screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById('ibadat-' + name);
  if(el) el.classList.add('active');
  if(name === 'quran') loadSurahs();
  if(name === 'adhkar'){ renderAdhkarTabs(); renderAdhkarList(); }
}

/* ===== الوضع الليلي ===== */
function toggleDark(){
  document.body.classList.toggle('dark');
  settings.darkMode = document.body.classList.contains('dark');
  localStorage.setItem('rihlati_settings', JSON.stringify(settings));
  const toggle = document.getElementById('darkToggle');
  if(toggle) toggle.checked = settings.darkMode;
}
if(settings.darkMode){ document.body.classList.add('dark'); }

/* ===== البطاقة ثلاثية الأبعاد ===== */
let welcomeFlipped = false;
let welcomeInterval = null;
function flipWelcome(){
  const card = document.getElementById('welcomeCard');
  card.classList.toggle('flipped');
  welcomeFlipped = !welcomeFlipped;
}
function startWelcomeRotation(){
  if(welcomeInterval) clearInterval(welcomeInterval);
  welcomeInterval = setInterval(() => {
    const card = document.getElementById('welcomeCard');
    if(card) card.classList.toggle('flipped');
  }, 6500);
}

/* ===== التحية ===== */
const hour = new Date().getHours();
const greetingText = document.getElementById('greetingText');
if(greetingText){
  greetingText.textContent = hour<12?'صباح النور 🌿': hour<18?'مساء النور ☀️':'مساء الخير 🌙';
}

/* ===== الموقع والمواقيت ===== */
const CAIRO = {lat:30.0444, lng:31.2357, city:'القاهرة'};
let prayerTimes = {};
let currentLoc = null;
const prayerOrder = ['fajr','sunrise','dhuhr','asr','maghrib','isha'];
const prayerNamesAr = {fajr:'الفجر',sunrise:'الشروق',dhuhr:'الظهر',asr:'العصر',maghrib:'المغرب',isha:'العشاء'};

function getUserLocation(){
  return new Promise(resolve=>{
    const saved = localStorage.getItem('rihlati_location');
    if(saved) return resolve(JSON.parse(saved));
    if(!navigator.geolocation) return resolve(CAIRO);
    navigator.geolocation.getCurrentPosition(
      pos=>resolve({lat:pos.coords.latitude, lng:pos.coords.longitude, city:'موقعك'}),
      ()=>resolve(CAIRO),
      {timeout:8000}
    );
  });
}

async function setManualLocation(){
  const city = document.getElementById('manualCity').value.trim();
  if(!city){ alert('اكتب اسم المدينة أولاً'); return; }
  try{
    const res = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=EG&method=${settings.calcMethod}`);
    const json = await res.json();
    if(!json.data){ alert('المدينة غير موجودة'); return; }
    const loc = {lat:json.data.meta.latitude, lng:json.data.meta.longitude, city:city};
    localStorage.setItem('rihlati_location', JSON.stringify(loc));
    currentLoc = loc;
    await fetchPrayerTimes(loc);
    alert('✅ تم تحديد الموقع: ' + city);
  }catch(e){ alert('تعذر تحديد الموقع'); }
}

async function fetchPrayerTimes(loc){
  currentLoc = loc;
  const today = new Date();
  const dateStr = `${String(today.getDate()).padStart(2,'0')}-${String(today.getMonth()+1).padStart(2,'0')}-${today.getFullYear()}`;
  const url = `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${loc.lat}&longitude=${loc.lng}&method=${settings.calcMethod}`;
  try{
    const res = await fetch(url);
    const json = await res.json();
    const t = json.data.timings;
    prayerTimes = {fajr:t.Fajr.split(' ')[0], sunrise:t.Sunrise.split(' ')[0], dhuhr:t.Dhuhr.split(' ')[0], asr:t.Asr.split(' ')[0], maghrib:t.Maghrib.split(' ')[0], isha:t.Isha.split(' ')[0]};
    const hijri = json.data.date.hijri;
    const hijriEl = document.getElementById('hijriDate');
    if(hijriEl) hijriEl.textContent = `${hijri.day} ${hijri.month.ar} ${hijri.year} هـ`;
    const locEl = document.getElementById('locationText');
    if(locEl) locEl.textContent = loc.city;
    renderPrayersGrid();
    updateNextPrayer();
    startCountdown();
    renderPrayerTasks();
  }catch(err){
    const locEl = document.getElementById('locationText');
    if(locEl) locEl.textContent = 'تعذر جلب المواقيت';
  }
}

function formatTime(t24){
  const [h,m]=t24.split(':').map(Number);
  const period=h>=12?'م':'ص';
  const h12=h%12||12;
  return `${h12}:${String(m).padStart(2,'0')} ${period}`;
}

async function load7Days(){
  const container=document.getElementById('sevenDaysContainer');
  const button=document.getElementById('load7DaysBtn');
  if(!container) return;
  container.innerHTML='<div class="loading">جاري تحميل مواقيت الأيام السبعة...</div>';
  if(button){button.disabled=true;button.textContent='⏳ جاري التحميل...';}
  try{
    const loc=currentLoc || await getUserLocation();
    if(!loc || !Number.isFinite(Number(loc.lat)) || !Number.isFinite(Number(loc.lng))) throw new Error('الموقع غير متاح');
    currentLoc=loc;
    const today=new Date();
    const dates=Array.from({length:7},(_,i)=>{
      const date=new Date(today.getFullYear(),today.getMonth(),today.getDate()+i);
      const dateStr=`${String(date.getDate()).padStart(2,'0')}-${String(date.getMonth()+1).padStart(2,'0')}-${date.getFullYear()}`;
      return {date,dateStr};
    });
    const results=await Promise.all(dates.map(async item=>{
      const url=`https://api.aladhan.com/v1/timings/${item.dateStr}?latitude=${encodeURIComponent(loc.lat)}&longitude=${encodeURIComponent(loc.lng)}&method=${encodeURIComponent(settings.calcMethod)}`;
      const response=await fetch(url);
      if(!response.ok) throw new Error('تعذر الاتصال بخدمة المواقيت');
      const json=await response.json();
      if(json.code!==200 || !json.data || !json.data.timings) throw new Error('بيانات المواقيت غير مكتملة');
      return {date:item.date,timings:json.data.timings};
    }));

    const sevenDayPrayers=[
      {key:'Fajr',name:'الفجر'},
      {key:'Sunrise',name:'الشروق'},
      {key:'Dhuhr',name:'الظهر'},
      {key:'Asr',name:'العصر'},
      {key:'Maghrib',name:'المغرب'},
      {key:'Isha',name:'العشاء'}
    ];
    const fragment=document.createDocumentFragment();
    results.forEach((day,index)=>{
      const card=document.createElement('div');
      card.className='seven-day-card';
      const heading=document.createElement('div');
      heading.className='seven-day-title';
      const dateLabel=day.date.toLocaleDateString('ar-EG',{weekday:'long',day:'numeric',month:'long'});
      heading.textContent=index===0 ? `اليوم · ${dateLabel}` : dateLabel;
      card.appendChild(heading);
      const grid=document.createElement('div');
      grid.className='seven-day-grid';
      sevenDayPrayers.forEach(prayer=>{
        const rawTime=day.timings[prayer.key];
        if(!rawTime) return;
        const tile=document.createElement('div');
        tile.className='seven-day-prayer';
        const name=document.createElement('div');
        name.className='p-name';
        name.textContent=prayer.name;
        const time=document.createElement('div');
        time.className='p-time';
        time.textContent=formatTime(rawTime.split(' ')[0]);
        tile.append(name,time);
        grid.appendChild(tile);
      });
      card.appendChild(grid);
      fragment.appendChild(card);
    });
    container.replaceChildren(fragment);
  }catch(error){
    console.error('load7Days error:',error);
    container.innerHTML='<div class="card" style="text-align:center;color:var(--muted)">تعذر تحميل المواقيت. تأكد من اتصال الإنترنت ثم حاول مرة أخرى.</div>';
  }finally{
    if(button){button.disabled=false;button.textContent='📅 تحديث مواقيت 7 أيام';}
  }
}
function renderPrayersGrid(){
  const grids=[...document.querySelectorAll('#homePrayersGrid, #prayersGrid')];
  if(!grids.length) return;
  grids.forEach(grid=>{
    grid.innerHTML='';
    prayerOrder.forEach(key=>{
      const div=document.createElement('div');
      div.className='prayer-tile';
      div.dataset.key=key;
      div.innerHTML=`<div class="p-name">${prayerNamesAr[key]}</div><div class="p-time">${formatTime(prayerTimes[key])}</div>`;
      grid.appendChild(div);
    });
  });
}

let countdownInterval=null;
let notificationInterval=null;
function timeToDate(hhmm){
  const [h,m]=hhmm.split(':').map(Number);
  const d=new Date(); d.setHours(h,m,0,0); return d;
}
function findNextPrayer(){
  const now=new Date();
  for(const key of prayerOrder){
    if(key === 'sunrise') continue; // الشروق للعرض فقط وليس صلاة مفروضة
    const t=timeToDate(prayerTimes[key]);
    if(t>now) return {key,time:t};
  }
  const tomorrow=new Date(); tomorrow.setDate(tomorrow.getDate()+1);
  const [h,m]=prayerTimes.fajr.split(':').map(Number);
  tomorrow.setHours(h,m,0,0);
  return {key:'fajr',time:tomorrow};
}
function updateNextPrayer(){
  if(typeof refreshDailyStorageKeys === 'function') refreshDailyStorageKeys();
  if(!prayerTimes.fajr) return;
  const {key}=findNextPrayer();
  const nameEl = document.getElementById('nextPrayerName');
  const timeEl = document.getElementById('nextPrayerTime');
  if(nameEl) nameEl.textContent=prayerNamesAr[key];
  if(timeEl) timeEl.textContent=formatTime(prayerTimes[key]);
  document.querySelectorAll('.prayer-tile').forEach(t=>t.classList.toggle('next',t.dataset.key===key));
}
function startCountdown(){
  if(countdownInterval) clearInterval(countdownInterval);
  if(window._prayerTimer) clearInterval(window._prayerTimer);
  if(notificationInterval) clearInterval(notificationInterval);
  const tick=()=>{
    if(!prayerTimes.fajr) return;
    const {time}=findNextPrayer();
    let diff=Math.floor((time-new Date())/1000);
    if(diff<0) diff=0;
    const h=String(Math.floor(diff/3600)).padStart(2,'0');
    const m=String(Math.floor((diff%3600)/60)).padStart(2,'0');
    const s=String(diff%60).padStart(2,'0');
    const el = document.getElementById('countdown');
    if(el) el.textContent=`${h}:${m}:${s}`;
  };
  tick();
  countdownInterval=setInterval(tick,1000);
  updateNextPrayer();
  window._prayerTimer=setInterval(updateNextPrayer,1000);
  notificationInterval=setInterval(checkPrayerNotification,30000);
}

/* ===== الإشعارات ===== */
async function toggleNotifications(){
  const toggle = document.getElementById('notificationsToggle');
  if(toggle.checked){
    if(!('Notification' in window)){ alert('متصفحك لا يدعم الإشعارات'); toggle.checked=false; return; }
    if(Notification.permission === 'default'){
      const perm = await Notification.requestPermission();
      if(perm !== 'granted'){ alert('لازم توافق على الإشعارات'); toggle.checked=false; return; }
    } else if(Notification.permission === 'denied'){
      alert('الإشعارات مرفوضة. فعّلها من إعدادات المتصفح'); toggle.checked=false; return;
    }
    settings.notifications = true;
  } else { settings.notifications = false; }
  localStorage.setItem('rihlati_settings', JSON.stringify(settings));
}
async function togglePrePrayerReminder(){
  const toggle = document.getElementById('prePrayerToggle');
  if(!toggle) return;
  if(toggle.checked){
    if(!('Notification' in window)){
      alert('متصفحك لا يدعم الإشعارات'); toggle.checked=false; return;
    }
    if(Notification.permission === 'default'){
      const perm = await Notification.requestPermission();
      if(perm !== 'granted'){ alert('لازم توافق على الإشعارات لتفعيل التذكير'); toggle.checked=false; return; }
    } else if(Notification.permission === 'denied'){
      alert('الإشعارات مرفوضة. فعّلها من إعدادات المتصفح'); toggle.checked=false; return;
    }
    settings.prePrayerReminder = true;
    // تفعيل التذكير المسبق يفعّل متابعة الإشعارات أيضًا.
    settings.notifications = true;
    const mainToggle = document.getElementById('notificationsToggle');
    if(mainToggle) mainToggle.checked = true;
  } else {
    settings.prePrayerReminder = false;
  }
  localStorage.setItem('rihlati_settings', JSON.stringify(settings));
}
function checkPrayerNotification(){
  if(!settings.notifications || !('Notification' in window) || Notification.permission !== 'granted') return;
  if(!prayerTimes.fajr) return;
  const now = new Date();
  prayerOrder.forEach(key=>{
    if(key === 'sunrise') return; // لا تُرسل تنبيهات أذان للشروق
    const t = timeToDate(prayerTimes[key]);
    const diff = Math.floor((now - t) / 1000);
    const dayKey = now.toDateString();
    const notifKey = 'notif_'+key+'_'+dayKey;
    if(diff >= 0 && diff <= 30 && !localStorage.getItem(notifKey)){
      localStorage.setItem(notifKey, '1');
      new Notification(`حان وقت صلاة ${prayerNamesAr[key]}`, {body: 'حي على الصلاة، حي على الفلاح 🕌'});
      playAdhanSound();
    }
    if(settings.prePrayerReminder){
      const secondsUntil = Math.floor((t - now) / 1000);
      const preKey = 'pre_notif_'+key+'_'+dayKey;
      if(secondsUntil <= 600 && secondsUntil >= 570 && !localStorage.getItem(preKey)){
        localStorage.setItem(preKey, '1');
        new Notification(`اقترب موعد صلاة ${prayerNamesAr[key]}`, {body: 'متبقي 10 دقائق على الأذان ⏰'});
      }
    }
  });
}
function playAdhanSound(){
  const sound = ADHAN_SOUNDS.find(s => s.id === settings.adhanSound);
  if(!sound) return;
  const audio = new Audio(sound.url);
  audio.play().catch(() => {});
}/* ===== تسجيل الصلوات ===== */
const PRAYER_TASKS = [
  {id:'fajr',label:'الفجر'},{id:'dhuhr',label:'الظهر'},{id:'asr',label:'العصر'},
  {id:'maghrib',label:'المغرب'},{id:'isha',label:'العشاء'}
];
let todayKey = 'rihlati_' + getLocalDateKey();
let prayerProgress = JSON.parse(localStorage.getItem(todayKey) || '{}');

function renderPrayerTasks(){
  const list = document.getElementById('prayerTasksList');
  if(!list) return;
  list.innerHTML = '';
  const {key:nextKey} = prayerTimes.fajr ? findNextPrayer() : {key:null};
  PRAYER_TASKS.forEach(t => {
    const div = document.createElement('div');
    const done = !!prayerProgress[t.id];
    const isCurrent = (t.id === nextKey);
    div.className = 'task' + (done?' done':'') + (!done && isCurrent?' current':'');
    div.innerHTML = `<div class="check">✓</div><div class="text">${t.label}${isCurrent?' (القادمة)':''}</div>`;
    div.onclick = () => {
      prayerProgress[t.id] = !prayerProgress[t.id];
      localStorage.setItem(todayKey, JSON.stringify(prayerProgress));
      renderPrayerTasks();
      updateHomeSummary();
    };
    list.appendChild(div);
  });
  const done = Object.values(prayerProgress).filter(Boolean).length;
  const fill = document.getElementById('prayerProgressFill');
  const txt = document.getElementById('prayerProgressText');
  if(fill) fill.style.width = (done/5*100) + '%';
  if(txt) txt.textContent = `${done} من 5 صلوات`;
}

/* ===== تحديث ملخص الرئيسية ===== */
function updateHomeSummary(){
  const prayers = Object.values(prayerProgress).filter(Boolean).length;
  const sp = document.getElementById('sumPrayers');
  if(sp) sp.textContent = `${prayers}/5`;
  const tasks = JSON.parse(localStorage.getItem('rihlati_tasks_'+getLocalDateKey()) || '[]');
  const tasksDone = tasks.filter(t => t.done).length;
  const st = document.getElementById('sumTasks');
  if(st) st.textContent = `${tasksDone}/${tasks.length}`;
  const adhkarCount = parseInt(localStorage.getItem('tasbihCount') || '0');
  const sa = document.getElementById('sumAdhkar');
  if(sa) sa.textContent = adhkarCount;
  const total = prayers + (tasks.length ? tasksDone/tasks.length*5 : 0);
  const pct = Math.round((total / 10) * 100);
  const spr = document.getElementById('sumProgress');
  if(spr) spr.textContent = Math.min(pct, 100) + '%';
  const heroProg = document.getElementById('homeHeroProgress');
  if(heroProg) heroProg.style.width = Math.min(pct, 100) + '%';
  updateTree();
}

/* ===== شجرة النمو ===== */
function updateTree(){
  const days = getStreakDays();
  let stage = 'بذرة', emoji = '🌱', hint = 'استمر في العبادة لتنمو شجرتك';
  if(days >= 3 && days < 7){ stage='برعم'; emoji='🌿'; hint='بداية جميلة، استمر'; }
  else if(days >= 7 && days < 14){ stage='شجرة صغيرة'; emoji='🌳'; hint='شجرتك تكبر يومًا بعد يوم'; }
  else if(days >= 14 && days < 30){ stage='شجرة مثمرة'; emoji='🌳✨'; hint='ما شاء الله، ثمار إيمانك'; }
  else if(days >= 30){ stage='بستان'; emoji='🌲🌳🌲'; hint='ما شاء الله! استمرار رائع'; }
  ['homeTree','gharsaTree'].forEach(id=>{ const el=document.getElementById(id); if(el) el.textContent = emoji; });
  ['homeTreeStage','gharsaStage'].forEach(id=>{ const el=document.getElementById(id); if(el) el.textContent = stage; });
  ['homeTreeHint','gharsaHint'].forEach(id=>{ const el=document.getElementById(id); if(el) el.textContent = hint; });
}

function getStreakDays(){
  return computeStreak(getDailyTaskLog(), getLocalDateKey()).current;
}

/* ===== الأذكار ===== */
const ADHKAR_CATEGORIES = [
  {id:'morning', name:'الصباح ☀️', items:[
    {text:'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ.',count:1},
    {text:'اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.',count:1},
    {text:'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.',count:3},
    {text:'بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.',count:3},
  ]},
  {id:'evening', name:'المساء 🌙', items:[
    {text:'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ.',count:1},
    {text:'اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ.',count:1},
    {text:'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.',count:3},
  ]},
  {id:'sleep', name:'النوم 🛏️', items:[
    {text:'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.',count:1},
    {text:'سُبْحَانَ اللَّهِ',count:33},{text:'الْحَمْدُ لِلَّهِ',count:33},{text:'اللَّهُ أَكْبَرُ',count:34},
  ]},
  {id:'wake', name:'الاستيقاظ 🌅', items:[
    {text:'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ.',count:1},
  ]},
  {id:'travel', name:'السفر ✈️', items:[
    {text:'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ.',count:1},
    {text:'اللَّهُمَّ هَوِّنْ عَلَيْنَا سَفَرَنَا هَذَا وَاطْوِ عَنَّا بُعْدَهُ.',count:1},
  ]},
  {id:'prayer', name:'بعد الصلاة 🕌', items:[
    {text:'أَسْتَغْفِرُ اللَّهَ.',count:3},
    {text:'اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ.',count:1},
    {text:'سُبْحَانَ اللَّهِ',count:33},{text:'الْحَمْدُ لِلَّهِ',count:33},{text:'اللَّهُ أَكْبَرُ',count:33},
  ]},
  {id:'general', name:'عام 📿', items:[
    {text:'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.',count:10},
    {text:'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.',count:100},
    {text:'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.',count:100},
    {text:'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ.',count:10},
  ]},,

  {id:'quranic', name:'أدعية قرآنية 📖', items:[
    {text:'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.',count:1},
    {text:'رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً ۚ إِنَّكَ أَنتَ الْوَهَّابُ.',count:1},
    {text:'رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي.',count:1},
    {text:'رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِن ذُرِّيَّتِي ۚ رَبَّنَا وَتَقَبَّلْ دُعَاءِ.',count:1},
    {text:'رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا.',count:1},
    {text:'رَبَّنَا اغْفِرْ لَنَا وَلِوَالِدَيْنَا يَوْمَ يَقُومُ الْحِسَابُ.',count:1},
    {text:'رَّبِّ زِدْنِي عِلْمًا.',count:1},
    {text:'رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ.',count:1},
    {text:'رَبَّنَا لَا تُؤَاخِذْنَا إِن نَّسِينَا أَوْ أَخْطَأْنَا.',count:1},
    {text:'رَبِّ هَبْ لِي مِن لَّدُنكَ ذُرِّيَّةً طَيِّبَةً ۖ إِنَّكَ سَمِيعُ الدُّعَاءِ.',count:1},
    {text:'رَبَّنَا تَقَبَّلْ مِنَّا ۖ إِنَّكَ أَنتَ السَّمِيعُ الْعَلِيمُ.',count:1},
    {text:'رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا.',count:1},
  ]},
  {id:'prophetic', name:'أدعية نبوية 🕌', items:[
    {text:'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى وَالتُّقَى وَالْعَفَافَ وَالْغِنَى.',count:1},
    {text:'اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ.',count:1},
    {text:'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ، وَضَلَعِ الدَّيْنِ وَغَلَبَةِ الرِّجَالِ.',count:1},
    {text:'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا.',count:1},
    {text:'اللَّهُمَّ اهْدِنِي فِيمَنْ هَدَيْتَ، وَعَافِنِي فِيمَنْ عَافَيْتَ، وَتَوَلَّنِي فِيمَنْ تَوَلَّيْتَ.',count:1},
    {text:'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْجَنَّةَ وَأَعُوذُ بِكَ مِنَ النَّارِ.',count:1},
    {text:'اللَّهُمَّ بَارِكْ لِي فِي أَهْلِي وَمَالِي وَوَلَدِي.',count:1},
    {text:'اللَّهُمَّ اجْعَلْ خَيْرَ عُمُرِي آخِرَهُ، وَخَيْرَ عَمَلِي خَاتِمَتَهُ، وَخَيْرَ أَيَّامِي يَوْمَ أَلْقَاكَ.',count:1},
    {text:'اللَّهُمَّ طَهِّرْ قَلْبِي مِنَ النِّفَاقِ، وَعَمَلِي مِنَ الرِّيَاءِ، وَلِسَانِي مِنَ الْكَذِبِ، وَعَيْنِي مِنَ الْخِيَانَةِ.',count:1},
    {text:'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ.',count:1},
    {text:'اللَّهُمَّ اقْسِمْ لَنَا مِنْ خَشْيَتِكَ مَا تَحُولُ بِهِ بَيْنَنَا وَبَيْنَ مَعَاصِيكَ.',count:1},
    {text:'اللَّهُمَّ إِنِّي أَسْأَلُكَ حُبَّكَ، وَحُبَّ مَنْ يُحِبُّكَ، وَحُبَّ الْعَمَلِ الَّذِي يُقَرِّبُنِي إِلَى حُبِّكَ.',count:1},
    {text:'اللَّهُمَّ ثَبِّتْ قَلْبِي عَلَى دِينِكَ.',count:1},
    {text:'اللَّهُمَّ أَغْنِنِي بِحَلَالِكَ عَنْ حَرَامِكَ، وَبِفَضْلِكَ عَمَّنْ سِوَاكَ.',count:1},
    {text:'اللَّهُمَّ ارْزُقْنِي حُسْنَ الْخُلُقِ وَحُسْنَ الصُّحْبَةِ.',count:1},
    {text:'اللَّهُمَّ اجْعَلْنِي مِنَ التَّوَّابِينَ وَاجْعَلْنِي مِنَ الْمُتَطَهِّرِينَ.',count:1},
  ]},
  {id:'istighfar', name:'استغفار 🤲', items:[
    {text:'أَسْتَغْفِرُ اللَّهَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ.',count:3},
    {text:'أَسْتَغْفِرُ اللَّهَ رَبِّي مِنْ كُلِّ ذَنْبٍ وَأَتُوبُ إِلَيْهِ.',count:100},
    {text:'اللَّهُمَّ اغْفِرْ لِي ذَنْبِي كُلَّهُ، دِقَّهُ وَجِلَّهُ، وَأَوَّلَهُ وَآخِرَهُ، وَعَلَانِيَتَهُ وَسِرَّهُ.',count:1},
    {text:'رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ.',count:100},
    {text:'اللَّهُمَّ إِنِّي ظَلَمْتُ نَفْسِي ظُلْمًا كَثِيرًا، وَلَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ، فَاغْفِرْ لِي مَغْفِرَةً مِنْ عِنْدِكَ وَارْحَمْنِي إِنَّكَ أَنْتَ الْغَفُورُ الرَّحِيمُ.',count:1},
    {text:'سَيِّدُ الِاسْتِغْفَارِ: اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي، فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ.',count:1},
  ]},
  {id:'faraj', name:'فرج وهم 💚', items:[
    {text:'لَا إِلَهَ إِلَّا اللَّهُ الْعَظِيمُ الْحَلِيمُ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ الْعَرْشِ الْعَظِيمِ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ السَّمَاوَاتِ وَرَبُّ الْأَرْضِ وَرَبُّ الْعَرْشِ الْكَرِيمِ.',count:1},
    {text:'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ زَوَالِ نِعْمَتِكَ، وَتَحَوُّلِ عَافِيَتِكَ، وَفُجَاءَةِ نِقْمَتِكَ، وَجَمِيعِ سَخَطِكَ.',count:1},
    {text:'يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ.',count:3},
    {text:'حَسْبِيَ اللَّهُ وَنِعْمَ الْوَكِيلُ.',count:7},
    {text:'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ.',count:10},
    {text:'اللَّهُمَّ اكْفِنِيهِمْ بِمَا شِئْتَ.',count:1},
    {text:'اللَّهُمَّ إِنِّي أَسْأَلُكَ صَبْرًا جَمِيلًا، وَفَرَجًا قَرِيبًا، وَرِزْقًا وَاسِعًا.',count:1},
    {text:'رَبِّ إِنِّي مَغْلُوبٌ فَانتَصِرْ.',count:3},
  ]},
];

let currentAdhkarCat = 'morning';
function renderAdhkarTabs(){
  const tabs = document.getElementById('adhkarTabs');
  if(!tabs) return;
  tabs.innerHTML = '';
  ADHKAR_CATEGORIES.forEach(cat => {
    const btn = document.createElement('button');
    btn.className = 'adhkar-tab' + (cat.id === currentAdhkarCat ? ' active' : '');
    btn.textContent = cat.name;
    btn.onclick = () => { currentAdhkarCat = cat.id; renderAdhkarTabs(); renderAdhkarList(); };
    tabs.appendChild(btn);
  });
}

function renderAdhkarList(){
  const list = document.getElementById('adhkarList');
  if(!list) return;
  list.innerHTML = '';
  const cat = ADHKAR_CATEGORIES.find(c => c.id === currentAdhkarCat);
  if(!cat) return;
  cat.items.forEach((d,i)=>{
    const item = document.createElement('div');
    item.className = 'adhkar-item';
    const key = 'adhkar_'+cat.id+'_'+i;
    let current = parseInt(localStorage.getItem(key)||'0');
    item.innerHTML = `<button class="share-btn" onclick="shareText('${d.text.replace(/'/g,"\\'")}','ذكر')">📤</button><div class="dhikr-text">${d.text}</div><div class="dhikr-meta"><span>${d.count} مرة</span><button class="counter-btn">${current}/${d.count}</button></div>`;
    list.appendChild(item);
    const btn = item.querySelector('.counter-btn');
    if(current>=d.count) btn.classList.add('done');
    btn.onclick = () => {
      current = Math.min(current+1, d.count);
      localStorage.setItem(key, current);
      btn.textContent = `${current}/${d.count}`;
      if(current>=d.count) btn.classList.add('done');
    };
  });
}

/* ===== المسبحة ===== */
let tasbihCount = parseInt(localStorage.getItem('tasbihCount')||'0');
const tasbihEl = document.getElementById('tasbihCount');
if(tasbihEl) tasbihEl.textContent = tasbihCount;
function incrementTasbih(){
  tasbihCount++;
  localStorage.setItem('tasbihCount', tasbihCount);
  if(tasbihEl) tasbihEl.textContent = tasbihCount;
  if(navigator.vibrate) navigator.vibrate(20);
}
function resetTasbih(){
  tasbihCount = 0;
  localStorage.setItem('tasbihCount', 0);
  if(tasbihEl) tasbihEl.textContent = 0;
}

/* ===== القبلة ===== */
const KAABA={lat:21.4225,lng:39.8262};
let rihlaQiblaBearing = null;
let rihlaQiblaListening = false;

function qiblaBearing(lat,lng){
  const toRad=d=>d*Math.PI/180, toDeg=r=>r*180/Math.PI;
  const φ1=toRad(lat), φ2=toRad(KAABA.lat);
  const Δλ=toRad(KAABA.lng-lng);
  const y=Math.sin(Δλ)*Math.cos(φ2);
  const x=Math.cos(φ1)*Math.sin(φ2)-Math.sin(φ1)*Math.cos(φ2)*Math.cos(Δλ);
  return (toDeg(Math.atan2(y,x))+360)%360;
}

function handleQiblaOrientation(e){
  if(rihlaQiblaBearing===null || !e) return;

  let heading = null;

  // iPhone: قيمة البوصلة المباشرة (اتجاه الشمال).
  if(typeof e.webkitCompassHeading === 'number' &&
     Number.isFinite(e.webkitCompassHeading)){
    heading = e.webkitCompassHeading;
  }
  // Android والأجهزة التي توفر اتجاهًا مطلقًا.
  // لا نستخدم alpha غير المطلق لأنه لا يحدد الشمال الحقيقي.
  else if(typeof e.alpha === 'number' && Number.isFinite(e.alpha) &&
          (e.absolute === true || e.type === 'deviceorientationabsolute')){
    heading = (360 - e.alpha) % 360;
  }

  if(heading===null) return;

  const angle=(rihlaQiblaBearing-heading+360)%360;
  const needle=document.getElementById('needle');
  if(needle) needle.style.transform=`translate(-50%,0) rotate(${angle}deg)`;

  const hint=document.getElementById('qiblaHint');
  if(hint) hint.textContent='حرّك الهاتف ببطء حتى يستقر اتجاه السهم نحو القبلة 🕋';
}

async function activateQiblaCompass(){
  const hint=document.getElementById('qiblaHint');

  if(typeof DeviceOrientationEvent==='undefined'){
    if(hint) hint.textContent='مستشعر الاتجاه غير متاح في هذا الجهاز. يمكنك استخدام زاوية القبلة المعروضة.';
    return;
  }

  // يجب طلب الإذن مباشرةً من ضغطة المستخدم على iPhone.
  if(typeof DeviceOrientationEvent.requestPermission==='function'){
    try{
      const permission=await DeviceOrientationEvent.requestPermission();
      if(permission!=='granted'){
        if(hint) hint.textContent='لم يتم السماح باستخدام البوصلة. فعّل إذن مستشعر الحركة من إعدادات المتصفح ثم حاول مرة أخرى.';
        return;
      }
    }catch(err){
      if(hint) hint.textContent='تعذّر تفعيل البوصلة. تأكد من فتح التطبيق عبر اتصال آمن HTTPS ثم أعد المحاولة.';
      return;
    }
  }

  if(!rihlaQiblaListening){
    window.addEventListener('deviceorientationabsolute',handleQiblaOrientation,true);
    window.addEventListener('deviceorientation',handleQiblaOrientation,true);
    rihlaQiblaListening=true;
  }

  if(hint) hint.textContent='تم تفعيل مستشعر الاتجاه. حرّك الهاتف ببطء لمعايرة البوصلة.';
}

async function initQibla(){
  const degEl=document.getElementById('qiblaDeg');
  const hint=document.getElementById('qiblaHint');
  const needle=document.getElementById('needle');

  try{
    const loc=await getUserLocation();
    rihlaQiblaBearing=qiblaBearing(loc.lat,loc.lng);
    if(degEl) degEl.textContent=`زاوية القبلة: ${rihlaQiblaBearing.toFixed(1)}° من الشمال`;
    if(needle) needle.style.transform=`translate(-50%,0) rotate(${rihlaQiblaBearing}deg)`;
  }catch(err){
    if(degEl) degEl.textContent='تعذّر تحديد زاوية القبلة';
    if(hint) hint.textContent='اسمح بالوصول إلى الموقع لتحديد اتجاه القبلة بدقة.';
    return;
  }

  if(hint){
    hint.textContent='';
    const message=document.createElement('span');
    message.textContent='اضغط لتفعيل البوصلة وتحريك السهم مع اتجاه الهاتف.';
    const button=document.createElement('button');
    button.type='button';
    button.textContent='تفعيل البوصلة';
    button.style.cssText='display:block;margin:12px auto 0;padding:10px 20px;border:0;border-radius:12px;background:var(--green);color:#fff;font:inherit;font-weight:700;cursor:pointer;';
    button.addEventListener('click',activateQiblaCompass);
    hint.append(message,button);
  }
}

/* ===== المهام (غرسة) ===== */
let TASKS_KEY = 'rihlati_tasks_' + getLocalDateKey();
let tasks = JSON.parse(localStorage.getItem(TASKS_KEY) || '[]');

function refreshDailyStorageKeys(){
  const localDay = getLocalDateKey();
  if(localDay === activeLocalDateKey) return false;
  activeLocalDateKey = localDay;
  todayKey = 'rihlati_' + localDay;
  TASKS_KEY = 'rihlati_tasks_' + localDay;
  try { prayerProgress = JSON.parse(localStorage.getItem(todayKey) || '{}') || {}; } catch(e) { prayerProgress = {}; }
  try { tasks = JSON.parse(localStorage.getItem(TASKS_KEY) || '[]') || []; } catch(e) { tasks = []; }
  if(!Array.isArray(tasks)) tasks = [];
  renderPrayerTasks();
  renderTasks();
  updateHomeSummary();
  return true;
}

function addTask(){
  const input = document.getElementById('newTaskInput');
  const txt = input.value.trim();
  if(!txt) return;
  tasks.push({id: Date.now(), text: txt, done: false});
  localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
  input.value = '';
  renderTasks();
  updateHomeSummary();
}

function renderTasks(){
  const list = document.getElementById('tasksList');
  if(!list) return;
  list.innerHTML = '';
  if(!tasks.length){
    list.innerHTML = '<div style="text-align:center;color:var(--muted);padding:20px;font-size:13px;">لا توجد مهام. أضف أول مهمة</div>';
  }
  tasks.forEach(t => {
    const div = document.createElement('div');
    div.className = 'task' + (t.done?' done':'');
    div.innerHTML = `<div class="check">✓</div><div class="text">${t.text}</div><button class="task-del" onclick="event.stopPropagation();deleteTask(${t.id})">🗑</button>`;
    div.onclick = () => { t.done = !t.done; localStorage.setItem(TASKS_KEY, JSON.stringify(tasks)); renderTasks(); updateHomeSummary(); };
    list.appendChild(div);
  });
  const done = tasks.filter(t => t.done).length;
  const fill = document.getElementById('tasksProgressFill');
  const txt = document.getElementById('tasksProgressText');
  const count = document.getElementById('tasksCount');
  if(fill) fill.style.width = tasks.length ? (done/tasks.length*100) + '%' : '0%';
  if(txt) txt.textContent = `${done} من ${tasks.length} مهام`;
  if(count) count.textContent = tasks.length;
  updateTreeSummary();
}

function deleteTask(id){
  if(!confirm('حذف المهمة؟')) return;
  tasks = tasks.filter(t => t.id !== id);
  localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
  renderTasks();
  updateHomeSummary();
}


/* ===== غرسة: التبويبات وملخص النمو ===== */
function switchGharsa(name){
  const allowed = ['tree','tasks','habits','goals'];
  if(!allowed.includes(name)) return;
  document.querySelectorAll('#screen-gharsa .sub-tab').forEach(t => {
    t.classList.toggle('active', t.dataset.gharsaTab === name);
  });
  document.querySelectorAll('#screen-gharsa .sub-screen').forEach(el => el.classList.remove('active'));
  const target = document.getElementById('gharsa-' + name);
  if(target) target.classList.add('active');
  if(name === 'tasks') renderTasks();
  if(name === 'habits') renderHabits();
  if(name === 'goals') renderGoals();
  if(name === 'tree') updateTreeSummary();
}

function gharsaRead(key, fallback){
  try{ const value = JSON.parse(localStorage.getItem(key) || 'null'); return value == null ? fallback : value; }
  catch(e){ return fallback; }
}
function gharsaTodayKey(){ return getLocalDateKey(); }
function updateTreeSummary(){
  const todayTasks = gharsaRead('rihlati_tasks_' + gharsaTodayKey(), []);
  const habits = gharsaRead('rihlati_habits', []);
  const goals = gharsaRead('rihlati_goals', []);
  const values = {
    treeTasks: Array.isArray(todayTasks) ? todayTasks.filter(t => t && t.done).length : 0,
    treeHabits: Array.isArray(habits) ? habits.length : 0,
    treeGoals: Array.isArray(goals) ? goals.filter(g => Number(g.current) < Number(g.total)).length : 0,
    treeStreak: getStreakDays()
  };
  Object.entries(values).forEach(([id,value]) => { const el=document.getElementById(id); if(el) el.textContent=value; });
  updateTree();
}

/* ===== غرسة: العادات ===== */
function openHabitModal(){
  const name=document.getElementById('habitName'); const freq=document.getElementById('habitFreq');
  if(name) name.value=''; if(freq) freq.value='daily';
  document.getElementById('habitModal').classList.add('show');
  if(name) name.focus();
}
function closeHabitModal(){ document.getElementById('habitModal').classList.remove('show'); }
function saveHabit(){
  const nameEl=document.getElementById('habitName');
  const name=nameEl ? nameEl.value.trim() : '';
  if(!name){ alert('اكتب اسم العادة'); if(nameEl) nameEl.focus(); return; }
  const freq=document.getElementById('habitFreq').value;
  const habits=gharsaRead('rihlati_habits', []);
  habits.push({id:Date.now(),name,freq,history:{},streak:0,createdAt:new Date().toISOString()});
  localStorage.setItem('rihlati_habits',JSON.stringify(habits));
  closeHabitModal(); renderHabits(); updateTreeSummary();
}
function deleteHabit(id){
  if(!confirm('حذف العادة؟')) return;
  const habits=gharsaRead('rihlati_habits', []).filter(h => Number(h.id)!==Number(id));
  localStorage.setItem('rihlati_habits',JSON.stringify(habits));
  renderHabits(); updateTreeSummary();
}
function toggleHabitToday(id){
  const habits=gharsaRead('rihlati_habits', []);
  const habit=habits.find(h => Number(h.id)===Number(id));
  if(!habit) return;
  if(!habit.history || typeof habit.history!=='object') habit.history={};
  const today=gharsaTodayKey();
  if(habit.history[today]) delete habit.history[today]; else habit.history[today]=true;
  let streak=0;
  for(let i=0;i<365;i++){
    const d=new Date(); d.setDate(d.getDate()-i);
    const key=getLocalDateKey(d);
    if(habit.history[key]) streak++; else break;
  }
  habit.streak=streak;
  localStorage.setItem('rihlati_habits',JSON.stringify(habits));
  renderHabits(); updateTreeSummary();
}
function renderHabits(){
  const list=document.getElementById('habitsList'); if(!list) return;
  const habits=gharsaRead('rihlati_habits', []);
  const count=document.getElementById('habitsCount'); if(count) count.textContent=habits.length;
  list.replaceChildren();
  if(!habits.length){
    const empty=document.createElement('div'); empty.style.cssText='text-align:center;color:var(--muted);padding:30px;font-size:13px;';
    empty.textContent='لا توجد عادات بعد. أضف أول عادة'; list.appendChild(empty); return;
  }
  const today=gharsaTodayKey();
  habits.forEach(h=>{
    if(!h.history || typeof h.history!=='object') h.history={};
    const done=!!h.history[today];
    const card=document.createElement('div'); card.className='habit-card';
    const header=document.createElement('div'); header.className='habit-header';
    const title=document.createElement('div'); title.className='habit-name'; title.textContent=h.name || 'عادة بدون اسم';
    const freq=document.createElement('div'); freq.className='habit-freq'; freq.textContent=h.freq==='weekly'?'أسبوعيًا':'يوميًا';
    header.append(title,freq);
    const body=document.createElement('div'); body.className='habit-body';
    const streak=document.createElement('div'); streak.className='habit-streak'; streak.append(document.createTextNode('🔥 '));
    const strong=document.createElement('strong'); strong.textContent=Number(h.streak)||0; streak.append(strong,document.createTextNode(' يوم متتالي'));
    const actions=document.createElement('div'); actions.className='habit-actions';
    const doneBtn=document.createElement('button'); doneBtn.className='habit-btn'+(done?' done':''); doneBtn.textContent=done?'✓ تم':'أنجزت'; doneBtn.onclick=()=>toggleHabitToday(h.id);
    const del=document.createElement('button'); del.className='habit-del'; del.type='button'; del.textContent='🗑'; del.setAttribute('aria-label','حذف العادة'); del.onclick=()=>deleteHabit(h.id);
    actions.append(doneBtn,del); body.append(streak,actions); card.append(header,body); list.appendChild(card);
  });
}

/* ===== غرسة: الأهداف والخطط ===== */
function openGoalModal(){
  const name=document.getElementById('goalName'), duration=document.getElementById('goalDuration'), steps=document.getElementById('goalSteps');
  if(name) name.value=''; if(duration) duration.value=''; if(steps) steps.value='10';
  document.getElementById('goalModal').classList.add('show'); if(name) name.focus();
}
function closeGoalModal(){ document.getElementById('goalModal').classList.remove('show'); }
function saveGoal(){
  const nameEl=document.getElementById('goalName'); const name=nameEl ? nameEl.value.trim() : '';
  const duration=document.getElementById('goalDuration').value.trim() || 'مفتوح';
  const raw=parseInt(document.getElementById('goalSteps').value,10);
  const steps=Number.isFinite(raw) ? Math.min(10000,Math.max(1,raw)) : 10;
  if(!name){ alert('اكتب اسم الهدف'); if(nameEl) nameEl.focus(); return; }
  const goals=gharsaRead('rihlati_goals', []);
  goals.push({id:Date.now(),name,duration,total:steps,current:0,createdAt:new Date().toISOString()});
  localStorage.setItem('rihlati_goals',JSON.stringify(goals));
  closeGoalModal(); renderGoals(); updateTreeSummary();
}
function deleteGoal(id){
  if(!confirm('حذف الهدف؟')) return;
  const goals=gharsaRead('rihlati_goals', []).filter(g => Number(g.id)!==Number(id));
  localStorage.setItem('rihlati_goals',JSON.stringify(goals));
  renderGoals(); updateTreeSummary();
}
function addGoalStep(id){
  const goals=gharsaRead('rihlati_goals', []); const goal=goals.find(g=>Number(g.id)===Number(id));
  if(!goal) return;
  const total=Math.max(1,Number(goal.total)||1); goal.current=Math.min(total,Math.max(0,Number(goal.current)||0)+1);
  localStorage.setItem('rihlati_goals',JSON.stringify(goals)); renderGoals(); updateTreeSummary();
}
function renderGoals(){
  const list=document.getElementById('goalsList'); if(!list) return;
  const goals=gharsaRead('rihlati_goals', []); const count=document.getElementById('goalsCount'); if(count) count.textContent=goals.length;
  list.replaceChildren();
  if(!goals.length){
    const empty=document.createElement('div'); empty.style.cssText='text-align:center;color:var(--muted);padding:30px;font-size:13px;';
    empty.textContent='لا توجد أهداف بعد. أضف أول هدف'; list.appendChild(empty); return;
  }
  goals.forEach(g=>{
    const total=Math.max(1,Number(g.total)||1), current=Math.min(total,Math.max(0,Number(g.current)||0));
    const pct=Math.round(current/total*100), done=current>=total;
    const card=document.createElement('div'); card.className='goal-card';
    const header=document.createElement('div'); header.className='goal-header';
    const title=document.createElement('div'); title.className='goal-name'; title.textContent=(g.name||'هدف بدون اسم')+(done?' ✅':'');
    const duration=document.createElement('div'); duration.className='goal-duration'; duration.textContent=g.duration||'مفتوح';
    header.append(title,duration);
    const bar=document.createElement('div'); bar.className='goal-progress-bar';
    const fill=document.createElement('div'); fill.className='goal-progress-fill'; fill.style.width=pct+'%'; bar.appendChild(fill);
    const footer=document.createElement('div'); footer.className='goal-steps';
    const progress=document.createElement('div'); progress.textContent=`${current} / ${total} خطوة (${pct}%)`;
    const actions=document.createElement('div'); actions.style.cssText='display:flex;gap:6px;align-items:center;';
    const step=document.createElement('button'); step.className='goal-step-btn'; step.textContent='+'; step.disabled=done; step.setAttribute('aria-label','إضافة خطوة للهدف'); step.onclick=()=>addGoalStep(g.id);
    const del=document.createElement('button'); del.className='habit-del'; del.type='button'; del.textContent='🗑'; del.setAttribute('aria-label','حذف الهدف'); del.onclick=()=>deleteGoal(g.id);
    actions.append(step,del); footer.append(progress,actions); card.append(header,bar,footer); list.appendChild(card);
  });
}

/* ===== المصحف ===== */
let surahsData=[]; let surahsLoaded=false;
let currentAudio=null; let currentAudioSurah=null; let isPlaying=false;
let tafsirEnabled = false;
let currentTafsirData = null;
const QURAN_CACHE = 'rihlati-quran';

async function isSurahDownloaded(num){
  try{ const cache = await caches.open(QURAN_CACHE); return !!(await cache.match(`https://api.alquran.cloud/v1/surah/${num}`)); }
  catch(e){ return false; }
}
async function fetchSurahData(num){
  const url = `https://api.alquran.cloud/v1/surah/${num}`;
  try{ const cache = await caches.open(QURAN_CACHE); const cached = await cache.match(url); if(cached) return await cached.json(); const res = await fetch(url); return await res.json(); }
  catch(e){ const res = await fetch(url); return await res.json(); }
}
async function fetchTafsir(num){
  try{ const res = await fetch(`https://api.alquran.cloud/v1/surah/${num}/ar.muyassar`); const json = await res.json(); return json.data.ayahs; }
  catch(e){ return null; }
}
async function downloadSurah(num, silent){
  const url = `https://api.alquran.cloud/v1/surah/${num}`;
  try{ const cache = await caches.open(QURAN_CACHE); const res = await fetch(url); await cache.put(url, res.clone()); if(!silent) updateSurahDownloadUI(num, true); return true; }
  catch(e){ if(!silent) alert('تعذر التحميل'); return false; }
}
async function updateSurahDownloadUI(num, downloaded){
  const btn = document.getElementById('dl-'+num);
  if(!btn) return;
  if(downloaded){ btn.classList.add('downloaded'); btn.classList.remove('downloading'); btn.textContent='✓'; }
  else { btn.classList.remove('downloaded','downloading'); btn.textContent='⬇'; }
}
async function handleDownloadClick(num, e){
  e.stopPropagation();
  const btn = document.getElementById('dl-'+num);
  if(btn.classList.contains('downloaded')) return;
  btn.classList.add('downloading'); btn.textContent = '...';
  const ok = await downloadSurah(num);
  if(!ok){ btn.classList.remove('downloading'); btn.textContent='⬇'; }
}
async function downloadAllSurahs(){
  const btn = document.getElementById('downloadAllBtn');
  btn.disabled = true; btn.textContent = '⏳ جاري التحميل...';
  for(const s of surahsData){
    const already = await isSurahDownloaded(s.number);
    if(!already) await downloadSurah(s.number, true);
    btn.textContent = `⏳ ${s.number}/${surahsData.length}`;
  }
  btn.textContent = '✅ تم التحميل';
  setTimeout(()=>{ btn.disabled = false; btn.textContent = '⬇️ تحميل كل السور للقراءة أوفلاين'; }, 2500);
  surahsData.forEach(async s => { if(await isSurahDownloaded(s.number)) updateSurahDownloadUI(s.number, true); });
}
async function loadSurahs(){
  if(surahsLoaded){ await renderSurahList(surahsData); renderBookmarkBanner(); return; }
  try{
    const res=await fetch('https://api.alquran.cloud/v1/surah');
    const json=await res.json();
    surahsData=json.data; surahsLoaded=true;
    await renderSurahList(surahsData); renderBookmarkBanner();
  }catch(err){ document.getElementById('surahListContainer').innerHTML='<div class="loading">تعذر تحميل السور</div>'; }
}
async function renderSurahList(data){
  const container=document.getElementById('surahListContainer');
  if(!container) return;
  container.innerHTML='';
  if(!data.length){ container.innerHTML='<div class="loading">لا توجد نتائج</div>'; return; }
  for(const s of data){
    const downloaded = await isSurahDownloaded(s.number);
    const div=document.createElement('div');
    div.className='surah-item';
    div.innerHTML=`<div class="surah-info"><div class="surah-num">${s.number}</div><div><div class="surah-name">${s.name}</div><div class="surah-meta">${s.numberOfAyahs} آية · ${s.revelationType==='Meccan'?'مكية':'مدنية'}</div></div></div><div class="surah-actions"><button class="dl-btn ${downloaded?'downloaded':''}" id="dl-${s.number}" onclick="handleDownloadClick(${s.number},event)">${downloaded?'✓':'⬇'}</button><div style="font-size:20px;color:var(--gold)">›</div></div>`;
    div.onclick = () => openSurah(s.number, s.name);
    container.appendChild(div);
  }
}
const surahSearchEl = document.getElementById('surahSearch');
if(surahSearchEl){
  surahSearchEl.addEventListener('input', async e=>{
    const q=e.target.value.trim();
    if(!q){ await renderSurahList(surahsData); return; }
    await renderSurahList(surahsData.filter(s=>s.name.includes(q)||String(s.number)===q));
  });
}
async function openSurah(num,name){
  if(currentAudio){ currentAudio.pause(); currentAudio=null; isPlaying=false; }
  document.getElementById('surahListView').style.display='none';
  document.getElementById('readingView').style.display='block';
  document.getElementById('readingTitle').textContent=name;
  document.getElementById('tafsirToggle').classList.remove('active');
  tafsirEnabled = false; currentTafsirData = null;
  const container=document.getElementById('versesContainer');
  container.innerHTML='<div class="loading">جاري تحميل السورة...</div>';
  window.scrollTo({top:0});
  currentAudioSurah = num;
  try{
    const json = await fetchSurahData(num);
    const verses=json.data.ayahs;
    container.innerHTML='';
    if(num!==1 && num!==9){
      const b=document.createElement('div'); b.className='bismillah'; b.textContent='بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ'; container.appendChild(b);
    }
    const wrap=document.createElement('div'); wrap.className='verses';
    verses.forEach((v,i)=>{
      const item=document.createElement('div'); item.className='verse-item'; item.dataset.idx=i;
      const shareTxt = v.text.replace(/'/g,"\\'");
      item.innerHTML=`<button class="share-btn" onclick="shareText('${shareTxt}','آية')">📤</button><div class="verse-ar">${v.text}<span class="verse-num">${v.numberInSurah}</span></div>`;
      wrap.appendChild(item);
    });
    container.appendChild(wrap);
    document.getElementById('audioPlayerContainer').innerHTML = `<div class="audio-player"><button id="playBtn" onclick="toggleAudio(${num})">▶️</button><div class="track-info">تلاوة مشاري العفاسي</div></div>`;
    localStorage.setItem('quranBookmark',JSON.stringify({surah:num,name:name.replace('سُورَةُ ','').trim(),at:Date.now()}));
    renderBookmarkBanner();
  }catch(err){ container.innerHTML='<div class="loading">تعذر تحميل السورة</div>'; }
}
async function toggleTafsir(){
  if(!currentAudioSurah) return;
  const toggleBtn = document.getElementById('tafsirToggle');
  if(tafsirEnabled){ tafsirEnabled=false; toggleBtn.classList.remove('active'); document.querySelectorAll('.verse-tafsir').forEach(el=>el.remove()); return; }
  tafsirEnabled = true; toggleBtn.classList.add('active');
  if(!currentTafsirData){ toggleBtn.textContent='...'; currentTafsirData = await fetchTafsir(currentAudioSurah); toggleBtn.textContent='تفسير'; }
  if(!currentTafsirData){ alert('تعذر تحميل التفسير'); tafsirEnabled=false; toggleBtn.classList.remove('active'); return; }
  document.querySelectorAll('.verse-item').forEach((el, i) => {
    if(currentTafsirData[i]){
      const tafsirDiv = document.createElement('div');
      tafsirDiv.className = 'verse-tafsir';
      tafsirDiv.innerHTML = `<div class="verse-tafsir-label">📖 التفسير الميسر</div>${currentTafsirData[i].text}`;
      el.appendChild(tafsirDiv);
    }
  });
}
function toggleAudio(num){
  const btn = document.getElementById('playBtn');
  if(currentAudio && currentAudioSurah === num){
    if(isPlaying){ currentAudio.pause(); isPlaying=false; btn.textContent='▶️'; }
    else { currentAudio.play(); isPlaying=true; btn.textContent='⏸️'; }
    return;
  }
  if(currentAudio) currentAudio.pause();
  currentAudio = new Audio(`https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${num}.mp3`);
  currentAudioSurah = num;
  currentAudio.play().then(()=>{ isPlaying=true; btn.textContent='⏸️'; }).catch(()=>alert('تعذر تشغيل الصوت'));
  currentAudio.onended = ()=>{ isPlaying=false; btn.textContent='▶️'; };
}
function closeReading(){
  if(currentAudio){ currentAudio.pause(); currentAudio=null; isPlaying=false; }
  document.getElementById('readingView').style.display='none';
  document.getElementById('surahListView').style.display='block';
  document.getElementById('audioPlayerContainer').innerHTML='';
  tafsirEnabled = false; currentTafsirData = null;
  window.scrollTo({top:0});
}
function renderBookmarkBanner(){
  const banner=document.getElementById('bookmarkBanner');
  if(!banner) return;
  const bookmark=JSON.parse(localStorage.getItem('quranBookmark')||'null');
  if(!bookmark){ banner.innerHTML=''; return; }
  banner.innerHTML=`<div class="bookmark-banner"><div>📖 آخر ما قرأت: <strong>${bookmark.name}</strong></div><button onclick="openSurah(${bookmark.surah},'${bookmark.name}')">متابعة</button></div>`;
}


/* ===== الشارات ===== */
function _badgesSafeArray(key){
  try{
    const value=JSON.parse(localStorage.getItem(key)||'[]');
    return Array.isArray(value)?value:[];
  }catch(e){return [];}
}
function _badgesSafeObject(key){
  try{
    const value=JSON.parse(localStorage.getItem(key)||'{}');
    return value && typeof value==='object' && !Array.isArray(value)?value:{};
  }catch(e){return {};}
}
function _badgesTotalPrayers(){
  let total=0;
  for(let i=0;i<365;i++){
    const d=new Date();d.setDate(d.getDate()-i);
    const key='rihlati_'+getLocalDateKey(d);
    total+=Object.values(_badgesSafeObject(key)).filter(Boolean).length;
  }
  return total;
}
function _badgesTotalTasks(){
  let total=0;
  for(let i=0;i<365;i++){
    const d=new Date();d.setDate(d.getDate()-i);
    const t=_badgesSafeArray('rihlati_tasks_'+getLocalDateKey(d));
    total+=t.filter(x=>x&&x.done).length;
  }
  return total;
}
function _badgesActiveDays(){
  let total=0;
  for(let i=0;i<365;i++){
    const d=new Date();d.setDate(d.getDate()-i);
    const date=getLocalDateKey(d);
    const prog=_badgesSafeObject('rihlati_'+date);
    const done=Object.values(prog).filter(Boolean).length;
    const tasks=_badgesSafeArray('rihlati_tasks_'+date);
    if(done>=1||tasks.length)total++;
  }
  return total;
}
const BADGES=[
  {id:'first_prayer',icon:'🕌',name:'أول خطوة',desc:'سجل صلاة',check:()=>_badgesTotalPrayers()>=1},
  {id:'week_streak',icon:'🔥',name:'أسبوع',desc:'7 أيام متتالية',check:()=>getStreakDays()>=7},
  {id:'month_streak',icon:'🌟',name:'شهر',desc:'30 يوم متتالي',check:()=>getStreakDays()>=30},
  {id:'100_prayers',icon:'💯',name:'100 صلاة',desc:'إجمالي 100 صلاة',check:()=>_badgesTotalPrayers()>=100},
  {id:'50_tasks',icon:'✅',name:'50 مهمة',desc:'مهام مكتملة',check:()=>_badgesTotalTasks()>=50},
  {id:'first_habit',icon:'🌱',name:'أول عادة',desc:'إنشاء عادة',check:()=>_badgesSafeArray('rihlati_habits').length>=1},
  {id:'habit_streak',icon:'🌿',name:'عادة مستمرة',desc:'10 أيام على عادة',check:()=>_badgesSafeArray('rihlati_habits').some(h=>h&&Number(h.streak)>=10)},
  {id:'first_goal',icon:'🎯',name:'أول هدف',desc:'إتمام هدف',check:()=>_badgesSafeArray('rihlati_goals').some(g=>g&&Number(g.current)>=Number(g.total)&&Number(g.total)>0)},
  {id:'5_goals',icon:'🏆',name:'5 أهداف',desc:'إتمام 5 أهداف',check:()=>_badgesSafeArray('rihlati_goals').filter(g=>g&&Number(g.current)>=Number(g.total)&&Number(g.total)>0).length>=5},
  {id:'tasbih_100',icon:'📿',name:'المسبحة',desc:'100 تسبيحة',check:()=>parseInt(localStorage.getItem('tasbihCount')||'0',10)>=100},
  {id:'quran_reader',icon:'📖',name:'قارئ',desc:'فتح المصحف',check:()=>!!localStorage.getItem('quranBookmark')},
  {id:'10_active',icon:'📅',name:'10 أيام',desc:'10 أيام نشاط',check:()=>_badgesActiveDays()>=10}
];
function renderBadges(){
  const grid=document.getElementById('badgesGrid');
  if(!grid)return;
  grid.innerHTML='';
  let earned=0;
  BADGES.forEach(b=>{
    let isEarned=false;
    try{isEarned=!!b.check();}catch(e){}
    if(isEarned)earned++;
    const card=document.createElement('div');
    card.className='badge-card'+(isEarned?' earned':'');
    const icon=document.createElement('div');icon.className='badge-icon';icon.textContent=b.icon;
    const name=document.createElement('div');name.className='badge-name';name.textContent=b.name;
    const desc=document.createElement('div');desc.className='badge-desc';desc.textContent=isEarned?'✓ مكتسبة':b.desc;
    card.append(icon,name,desc);
    grid.appendChild(card);
  });
  const countEl=document.getElementById('badgesCount');
  if(countEl)countEl.textContent=earned+'/'+BADGES.length;
}

/* ===== الإحصائيات ===== */
function renderStats(){
  let streak = getStreakDays();
  renderBadges();
  const sn = document.getElementById('streakNumber');
  if(sn) sn.textContent = streak;
  const streakStats = computeStreak(getDailyTaskLog(), getLocalDateKey());
  let totalPrayers = 0, totalTasksDone = 0, activeDays = 0;
  for(let i=365; i>=0; i--){
    const d = new Date(); d.setDate(d.getDate()-i);
    const key = 'rihlati_' + getLocalDateKey(d);
    const prog = JSON.parse(localStorage.getItem(key)||'{}');
    const done = Object.values(prog).filter(Boolean).length;
    totalPrayers += done;
    const t = JSON.parse(localStorage.getItem('rihlati_tasks_'+getLocalDateKey(d))||'[]');
    totalTasksDone += t.filter(x=>x.done).length;
    if(done >= 1 || t.length) activeDays++;
  }
  const ap = document.getElementById('achPrayers'); if(ap) ap.textContent = totalPrayers;
  const at = document.getElementById('achTasks'); if(at) at.textContent = totalTasksDone;
  const ab = document.getElementById('achBestStreak'); if(ab) ab.textContent = streakStats.best;
  const ad = document.getElementById('achActiveDays'); if(ad) ad.textContent = activeDays;
  const chart = document.getElementById('weekChart');
  if(!chart) return;
  chart.innerHTML = '';
  const dayNames = ['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];
  for(let i=6; i>=0; i--){
    const d = new Date(); d.setDate(d.getDate()-i);
    const key = 'rihlati_' + getLocalDateKey(d);
    const prog = JSON.parse(localStorage.getItem(key)||'{}');
    const done = Object.values(prog).filter(Boolean).length;
    const pct = (done / 5) * 100;
    const col = document.createElement('div');
    col.className = 'week-day';
    col.innerHTML = `<div class="week-bar"><div class="week-bar-fill" style="height:${pct}%"></div></div><div class="day-name">${dayNames[d.getDay()]}</div>`;
    chart.appendChild(col);
  }
}


/* ===== مقارنة الإحصائيات الشهرية ===== */
function _monthStats(offset){
  const now = new Date();
  const target = new Date(now.getFullYear(), now.getMonth() - offset, 1);
  const year = target.getFullYear();
  const month = target.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  let prayers = 0, tasksDone = 0, activeDays = 0;
  let bestStreak = 0, curStreak = 0;

  for(let day = 1; day <= daysInMonth; day++){
    const dateObj = new Date(year, month, day);
    // لا نحسب الأيام المستقبلية في الشهر الحالي.
    if(dateObj > now) break;

    // نستخدم نفس تنسيق مفاتيح التخزين المعتمد في بقية التطبيق لضمان قراءة البيانات القديمة.
    const dateKey = getLocalDateKey(dateObj);
    let prog = {}, tasks = [];
    try { prog = JSON.parse(localStorage.getItem('rihlati_' + dateKey) || '{}') || {}; } catch(e) { prog = {}; }
    try { tasks = JSON.parse(localStorage.getItem('rihlati_tasks_' + dateKey) || '[]') || []; } catch(e) { tasks = []; }

    const prayerCount = Object.values(prog).filter(Boolean).length;
    const completedTasks = Array.isArray(tasks) ? tasks.filter(x => x && x.done).length : 0;
    prayers += prayerCount;
    tasksDone += completedTasks;
    if(prayerCount > 0 || (Array.isArray(tasks) && tasks.length > 0)) activeDays++;

    if(completedTasks >= DAILY_TARGET){
      curStreak++;
      if(curStreak > bestStreak) bestStreak = curStreak;
    } else {
      curStreak = 0;
    }
  }
  return {year, month, daysInMonth, prayers, tasksDone, activeDays, bestStreak};
}

function renderMonthlyStats(){
  const el = document.getElementById('monthlyStats');
  if(!el) return;
  const current = _monthStats(0), previous = _monthStats(1);
  const monthName = (y,m) => new Date(y,m,1).toLocaleDateString('ar-EG',{month:'long',year:'numeric'});
  const metric = (label, nowValue, beforeValue, unit) => {
    const diff = nowValue - beforeValue;
    const pct = beforeValue > 0 ? Math.round(Math.abs(diff) / beforeValue * 100) : (nowValue > 0 ? 100 : 0);
    const state = diff > 0 ? 'تحسن' : diff < 0 ? 'انخفاض' : 'ثابت';
    const sign = diff > 0 ? '+' : '';
    return `<div class="summary-card"><div class="label">${label}</div><div class="value">${nowValue}</div><div class="sub">الشهر الماضي: ${beforeValue} ${unit}</div><div class="sub">${state}: ${sign}${diff} (${pct}%)</div></div>`;
  };
  el.innerHTML = `<div class="summary-grid">
    ${metric('الصلوات المسجلة',current.prayers,previous.prayers,'صلاة')}
    ${metric('المهام المكتملة',current.tasksDone,previous.tasksDone,'مهمة')}
    ${metric('أيام النشاط',current.activeDays,previous.activeDays,'يوم')}
    ${metric('أفضل سلسلة (3 مهام يوميًا)',current.bestStreak,previous.bestStreak,'يوم')}
  </div>
  <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:12px;color:var(--muted);font-size:12px">
    <span>الحالي: ${monthName(current.year,current.month)}</span>
    <span>السابق: ${monthName(previous.year,previous.month)}</span>
  </div>`;
}

/* ===== السجل ===== */
function renderHistory(){
  const list = document.getElementById('historyList');
  if(!list) return;
  list.innerHTML = '';
  let hasData = false;
  for(let i=0; i<30; i++){
    const d = new Date(); d.setDate(d.getDate()-i);
    const key = 'rihlati_' + getLocalDateKey(d);
    const prog = JSON.parse(localStorage.getItem(key)||'{}');
    const done = Object.values(prog).filter(Boolean).length;
    if(done === 0) continue;
    hasData = true;
    const pct = Math.round((done/5)*100);
    const div = document.createElement('div');
    div.className = 'history-item';
    div.innerHTML = `<div><div class="h-date">${d.toLocaleDateString('ar-EG',{weekday:'long',day:'numeric',month:'short'})}</div><div class="h-bar"><div class="h-bar-fill" style="width:${pct}%"></div></div></div><div class="h-pct">${pct}%</div>`;
    list.appendChild(div);
  }
  if(!hasData) list.innerHTML = '<div style="text-align:center;color:var(--muted);padding:30px;font-size:13px;">لا يوجد سجل بعد. ابدأ بتسجيل صلواتك</div>';
}

/* ===== أسماء الله ===== */
const ALLAH_NAMES = [
  {n:'الرَّحْمَنُ',m:'الذي وسعت رحمته كل شيء'},{n:'الرَّحِيمُ',m:'الذي يرحم عباده المؤمنين'},
  {n:'الْمَلِكُ',m:'المالك المتصرف في ملكه'},{n:'الْقُدُّوسُ',m:'المنزه عن كل نقص'},
  {n:'السَّلَامُ',m:'الذي سلم من كل عيب'},{n:'الْمُؤْمِنُ',m:'المصدق لرسله'},
  {n:'الْمُهَيْمِنُ',m:'الرقيب على خلقه'},{n:'الْعَزِيزُ',m:'الغالب الذي لا يُغلب'},
  {n:'الْجَبَّارُ',m:'جابر كل مكسور'},{n:'الْمُتَكَبِّرُ',m:'المتعالي عن صفات الخلق'},
  {n:'الْخَالِقُ',m:'الذي خلق كل شيء'},{n:'الْبَارِئُ',m:'المبدع بلا مثال'},
  {n:'الْمُصَوِّرُ',m:'الذي صور الموجودات'},{n:'الْغَفَّارُ',m:'الذي يغفر الذنوب'},
  {n:'الْقَهَّارُ',m:'القاهر بقدرته'},{n:'الْوَهَّابُ',m:'الذي يعطي بلا مقابل'},
  {n:'الرَّزَّاقُ',m:'الذي يرزق خلقه'},{n:'الْفَتَّاحُ',m:'الذي يفتح أبواب الرحمة'},
  {n:'الْعَلِيمُ',m:'المحيط بكل شيء علمًا'},{n:'الْقَابِضُ',m:'الذي يقبض ويبسط'},
  {n:'الْبَاسِطُ',m:'الذي يبسط الرزق'},{n:'الْخَافِضُ',m:'الذي يخفض المتكبرين'},
  {n:'الرَّافِعُ',m:'الذي يرفع المتواضعين'},{n:'الْمُعِزُّ',m:'الذي يعز من يشاء'},
  {n:'الْمُذِلُّ',m:'الذي يذل من يشاء'},{n:'السَّمِيعُ',m:'الذي يسمع كل شيء'},
  {n:'الْبَصِيرُ',m:'الذي يرى كل شيء'},{n:'الْحَكَمُ',m:'الذي يحكم بالعدل'},
  {n:'الْعَدْلُ',m:'الذي لا يجور'},{n:'اللَّطِيفُ',m:'اللطيف بعباده'},
  {n:'الْخَبِيرُ',m:'المحيط ببواطن الأمور'},{n:'الْحَلِيمُ',m:'الذي لا يعاجل'},
  {n:'الْعَظِيمُ',m:'العظيم في ذاته'},{n:'الْغَفُورُ',m:'الذي يغفر ويعفو'},
  {n:'الشَّكُورُ',m:'الذي يجزي بالكثير'},{n:'الْعَلِيُّ',m:'المرتفع فوق كل شيء'},
  {n:'الْكَبِيرُ',m:'الكبير في ذاته'},{n:'الْحَفِيظُ',m:'الذي يحفظ كل شيء'},
  {n:'الْمُقِيتُ',m:'الذي يخلق الأقوات'},{n:'الْحَسِيبُ',m:'الذي يحاسب خلقه'},
  {n:'الْجَلِيلُ',m:'الموصوف بالجلال'},{n:'الْكَرِيمُ',m:'الكثير الخير'},
  {n:'الرَّقِيبُ',m:'المراقب لأحوال خلقه'},{n:'الْمُجِيبُ',m:'الذي يجيب الداعين'},
  {n:'الْوَاسِعُ',m:'الواسع الرحمة'},{n:'الْحَكِيمُ',m:'الذي يضع الأمور مواضعها'},
  {n:'الْوَدُودُ',m:'المحب لأوليائه'},{n:'الْمَجِيدُ',m:'الشريف العظيم'},
  {n:'الْبَاعِثُ',m:'الذي يبعث الخلق'},{n:'الشَّهِيدُ',m:'الحاضر الذي لا يغيب'},
  {n:'الْحَقُّ',m:'الثابت الذي لا يتغير'},{n:'الْوَكِيلُ',m:'القائم بمصالح عباده'},
  {n:'الْقَوِيُّ',m:'كامل القوة'},{n:'الْمَتِينُ',m:'الشديد القوي'},
  {n:'الْوَلِيُّ',m:'الناصر لعباده'},{n:'الْحَمِيدُ',m:'المحمود على كل حال'},
  {n:'الْمُحْصِي',m:'الذي أحصى كل شيء'},{n:'الْمُبْدِئُ',m:'الذي بدأ الخلق'},
  {n:'الْمُعِيدُ',m:'الذي يعيد الخلق'},{n:'الْمُحْيِي',m:'الذي يحيي الأموات'},
  {n:'الْمُمِيتُ',m:'الذي يميت الأحياء'},{n:'الْحَيُّ',m:'الحي حياة كاملة'},
  {n:'الْقَيُّومُ',m:'القائم بنفسه'},{n:'الْوَاجِدُ',m:'الغني الذي لا يفتقر'},
  {n:'الْمَاجِدُ',m:'الكريم الشريف'},{n:'الْوَاحِدُ',m:'المتفرد بذاته'},
  {n:'الْأَحَدُ',m:'الفرد بلا شريك'},{n:'الصَّمَدُ',m:'السيد الذي تصمد إليه الخلائق'},
  {n:'الْقَادِرُ',m:'القادر على كل شيء'},{n:'الْمُقْتَدِرُ',m:'التام القدرة'},
  {n:'الْمُقَدِّمُ',m:'الذي يقدم من يشاء'},{n:'الْمُؤَخِّرُ',m:'الذي يؤخر من يشاء'},
  {n:'الْأَوَّلُ',m:'ليس قبله شيء'},{n:'الْآخِرُ',m:'ليس بعده شيء'},
  {n:'الظَّاهِرُ',m:'الظاهر بأدلته'},{n:'الْبَاطِنُ',m:'المحتجب عن الأبصار'},
  {n:'الْوَالِي',m:'المالك المتصرف'},{n:'الْمُتَعَالِي',m:'المرتفع عن النقص'},
  {n:'الْبَرُّ',m:'المحسن إلى خلقه'},{n:'التَّوَّابُ',m:'الذي يقبل التوبة'},
  {n:'الْمُنْتَقِمُ',m:'الذي ينتقم من الظالمين'},{n:'الْعَفُوُّ',m:'كثير العفو'},
  {n:'الرَّءُوفُ',m:'شديد الرحمة'},{n:'مَالِكُ الْمُلْكِ',m:'المتصرف في ملكه'},
  {n:'ذُو الْجَلَالِ وَالْإِكْرَامِ',m:'المستحق للتعظيم'},{n:'الْمُقْسِطُ',m:'العادل في حكمه'},
  {n:'الْجَامِعُ',m:'الذي يجمع الخلائق'},{n:'الْغَنِيُّ',m:'الغني عن كل شيء'},
  {n:'الْمُغْنِي',m:'الذي يغني من يشاء'},{n:'الْمَانِعُ',m:'الذي يمنع ما يشاء'},
  {n:'الضَّارُّ',m:'الذي يضر بحكمته'},{n:'النَّافِعُ',m:'الذي ينفع برحمته'},
  {n:'النُّورُ',m:'الهادي المنير'},{n:'الْهَادِي',m:'الذي يهدي للهدى'},
  {n:'الْبَدِيعُ',m:'خالق بلا مثال'},{n:'الْبَاقِي',m:'الدائم الذي لا يفنى'},
  {n:'الْوَارِثُ',m:'الباقي بعد الفناء'},{n:'الرَّشِيدُ',m:'أفعاله كلها حكمة'},
  {n:'الصَّبُورُ',m:'الذي لا يعاجل بالعقوبة'}
];
function renderAllahNames(){
  const grid = document.getElementById('namesGrid');
  if(!grid) return;
  grid.innerHTML = '';
  ALLAH_NAMES.forEach((name, i) => {
    const card = document.createElement('div');
    card.className = 'name-card';
    card.innerHTML = `<button class="share-btn" onclick="event.stopPropagation();shareText('${name.n} — ${name.m.replace(/'/g,"\\'")}','أسماء الله')">📤</button><div class="name-num">${i+1}</div><div class="name-ar">${name.n}</div>`;
    card.onclick = () => showNameModal(i);
    grid.appendChild(card);
  });
}
function showNameModal(i){
  document.getElementById('modalNum').textContent = `الاسم ${i+1} من 99`;
  document.getElementById('modalName').textContent = ALLAH_NAMES[i].n;
  document.getElementById('modalMeaning').textContent = ALLAH_NAMES[i].m;
  document.getElementById('nameModal').classList.add('show');
}
function closeNameModal(){ document.getElementById('nameModal').classList.remove('show'); }

/* ===== دعاء وآية اليوم ===== */
const DAILY_DUAS = [
  'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى وَالتُّقَى وَالْعَفَافَ وَالْغِنَى.',
  'اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ.',
  'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ وَالْعَجْزِ وَالْكَسَلِ.',
  'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا وَرِزْقًا طَيِّبًا وَعَمَلًا مُتَقَبَّلًا.',
  'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.',
  'يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ أَصْلِحْ لِي شَأْنِي كُلَّهُ.',
  'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْجَنَّةَ وَأَعُوذُ بِكَ مِنَ النَّارِ.',
];
const DAILY_AYAT = [
  {v:'إِنَّ مَعَ الْعُسْرِ يُسْرًا',r:'الشرح 6'},
  {v:'وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ',r:'الطلاق 3'},
  {v:'فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ',r:'البقرة 152'},
  {v:'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ',r:'البقرة 153'},
  {v:'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ',r:'الرعد 28'},
  {v:'وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا',r:'الطلاق 2'},
  {v:'وَقَالَ رَبُّكُمُ ادْعُونِي أَسْتَجِبْ لَكُمْ',r:'غافر 60'},
];
function renderDailyDua(){
  const idx = Math.floor(Date.now()/86400000) % DAILY_DUAS.length;
  const dua = DAILY_DUAS[idx];
  const el = document.getElementById('duaCard');
  if(el) el.innerHTML = `<button class="share-btn" onclick="shareText('${dua.replace(/'/g,"\\'")}','دعاء')">📤</button><div class="dua-label">🤲 دعاء اليوم</div><div class="dua-text">${dua}</div>`;
}
function renderDailyAyah(){
  const idx = Math.floor(Date.now()/86400000) % DAILY_AYAT.length;
  const a = DAILY_AYAT[idx];
  const el = document.getElementById('dailyAyah');
  if(!el || !a) return;
  const escapeHtml = value => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const shareValue = `${a.v} — ${a.r}`.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
  el.innerHTML = `
    <div class="reflection-header">
      <span>Daily Reflection</span>
      <span>آية اليوم</span>
    </div>
    <div class="reflection-text">"${escapeHtml(a.v)}"</div>
    <div class="reflection-footer">
      <span>سورة ${escapeHtml(a.r)}</span>
      <button class="btn-share" style="color:var(--gold);font-size:18px;background:none;border:none;" onclick="shareText('${shareValue}','آية اليوم')">↗️</button>
    </div>
  `;
}

/* ===== النسخ الاحتياطي الآمن ===== */
const BACKUP_SCHEMA = 1;
const CURRENT_APP_VERSION = '10.0.0';
const BACKUP_MAX_BYTES = 20 * 1024 * 1024;

/** ترتيب ثابت لمفاتيح JSON مع رفض القيم غير القابلة للتسلسل والدوران */
function stableStringify(value) {
  const ancestors = new WeakSet();
  function serialize(item) {
    if (item === null || typeof item === 'string' || typeof item === 'boolean') {
      return JSON.stringify(item);
    }
    if (typeof item === 'number') {
      if (!Number.isFinite(item)) throw new TypeError('قيمة رقمية غير صالحة');
      return JSON.stringify(item);
    }
    if (typeof item !== 'object') {
      throw new TypeError('بيانات غير مدعومة في النسخة الاحتياطية');
    }
    if (ancestors.has(item)) throw new TypeError('بيانات دائرية غير مدعومة');
    ancestors.add(item);
    let result;
    if (Array.isArray(item)) {
      result = '[' + item.map(serialize).join(',') + ']';
    } else {
      const proto = Object.getPrototypeOf(item);
      if (proto !== Object.prototype && proto !== null) {
        throw new TypeError('نوع كائن غير مدعوم في النسخة الاحتياطية');
      }
      result = '{' + Object.keys(item).sort().map(key =>
        JSON.stringify(key) + ':' + serialize(item[key])
      ).join(',') + '}';
    }
    ancestors.delete(item);
    return result;
  }
  return serialize(value);
}

async function computeChecksum(data) {
  if (!globalThis.crypto || !crypto.subtle || typeof TextEncoder === 'undefined') {
    throw new Error('التحقق SHA-256 غير متاح. افتح التطبيق عبر HTTPS أو localhost.');
  }
  const bytes = new TextEncoder().encode(stableStringify(data));
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function collectLocalStorageSnapshot() {
  const data = Object.create(null);
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key !== null) data[key] = localStorage.getItem(key);
  }
  return data;
}

async function exportBackup(dataObject) {
  if (!dataObject || typeof dataObject !== 'object' || Array.isArray(dataObject)) {
    throw new TypeError('بيانات النسخة الاحتياطية غير صالحة');
  }
  const payload = {
    schema: BACKUP_SCHEMA,
    appVersion: CURRENT_APP_VERSION,
    exportedAt: new Date().toISOString(),
    data: dataObject
  };
  payload.checksum = await computeChecksum(payload.data);
  return JSON.stringify(payload, null, 2);
}

function checkDataShape(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    return 'حقل البيانات غير صالح.';
  }
  // النسخة تحفظ خريطة localStorage كاملة: اسم المفتاح ← نص القيمة.
  for (const key of Object.keys(data)) {
    if (typeof data[key] !== 'string') {
      return `قيمة التخزين للمفتاح ${key} يجب أن تكون نصًا.`;
    }
  }
  return null;
}

async function validateBackup(rawText) {
  if (typeof rawText !== 'string' || !rawText.trim()) {
    return { ok: false, error: 'الملف فارغ أو غير صالح.' };
  }
  if (new TextEncoder().encode(rawText).length > BACKUP_MAX_BYTES) {
    return { ok: false, error: 'حجم النسخة الاحتياطية أكبر من 20 ميجابايت.' };
  }
  let parsed;
  try { parsed = JSON.parse(rawText); }
  catch { return { ok: false, error: 'الملف ليس بصيغة JSON صحيحة.' }; }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { ok: false, error: 'بنية النسخة الاحتياطية غير صالحة.' };
  }
  const required = ['schema', 'appVersion', 'exportedAt', 'checksum', 'data'];
  for (const key of required) {
    if (!Object.prototype.hasOwnProperty.call(parsed, key)) {
      return { ok: false, error: `حقل مفقود في النسخة الاحتياطية: ${key}` };
    }
  }
  if (parsed.schema !== BACKUP_SCHEMA) {
    return { ok: false, error: `مخطط النسخة (${parsed.schema}) غير متوافق مع المخطط الحالي (${BACKUP_SCHEMA}).` };
  }
  if (typeof parsed.appVersion !== 'string' || !parsed.appVersion.trim()) {
    return { ok: false, error: 'إصدار التطبيق غير صالح.' };
  }
  if (typeof parsed.exportedAt !== 'string' || !Number.isFinite(Date.parse(parsed.exportedAt))) {
    return { ok: false, error: 'تاريخ إنشاء النسخة غير صالح.' };
  }
  if (typeof parsed.checksum !== 'string' || !/^[a-f0-9]{64}$/i.test(parsed.checksum)) {
    return { ok: false, error: 'بصمة النسخة الاحتياطية غير صالحة.' };
  }
  const shapeError = checkDataShape(parsed.data);
  if (shapeError) return { ok: false, error: shapeError };
  try {
    const expected = await computeChecksum(parsed.data);
    if (expected !== parsed.checksum.toLowerCase()) {
      return { ok: false, error: 'فشل التحقق من سلامة البيانات. الملف تالف أو معدّل.' };
    }
  } catch (error) {
    return { ok: false, error: error.message || 'تعذر التحقق من بصمة النسخة.' };
  }
  return { ok: true, data: parsed.data, appVersion: parsed.appVersion, exportedAt: parsed.exportedAt };
}

function snapshotCurrentState() {
  const before = collectLocalStorageSnapshot();
  return async function rollback() {
    localStorage.clear();
    for (const key of Object.keys(before)) localStorage.setItem(key, before[key]);
    // تحقق من استعادة كل المفاتيح والقيم السابقة
    if (localStorage.length !== Object.keys(before).length) throw new Error('Rollback verification failed');
    for (const key of Object.keys(before)) {
      if (localStorage.getItem(key) !== before[key]) throw new Error('Rollback data mismatch');
    }
  };
}

function applyBackupData(data) {
  // الاستعادة استبدال كامل لخريطة localStorage التي تم تصديرها.
  localStorage.clear();
  for (const key of Object.keys(data)) localStorage.setItem(key, data[key]);
}

function verifyAfterRestore(data) {
  const expectedKeys = Object.keys(data);
  if (localStorage.length !== expectedKeys.length) return false;
  return expectedKeys.every(key => localStorage.getItem(key) === data[key]);
}

async function restoreBackup(rawText) {
  const result = await validateBackup(rawText);
  if (!result.ok) return { success: false, error: result.error };
  const rollback = snapshotCurrentState();
  try {
    applyBackupData(result.data);
    if (!verifyAfterRestore(result.data)) throw new Error('Restore verification failed');
    return { success: true, appVersion: result.appVersion, exportedAt: result.exportedAt };
  } catch (error) {
    try {
      await rollback();
      return { success: false, error: 'فشلت الاستعادة، وتمت استعادة البيانات السابقة.' };
    } catch (rollbackError) {
      return { success: false, error: 'فشلت الاستعادة وفشل التراجع التلقائي. لا تغلق التطبيق، وافحص التخزين فورًا.' };
    }
  }
}

async function backupData() {
  try {
    const raw = await exportBackup(collectLocalStorageSnapshot());
    const blob = new Blob([raw], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rihlati_backup_${getLocalDateKey()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    alert('✅ تم إنشاء النسخة الاحتياطية بنجاح. احتفظ بالملف في مكان آمن.');
  } catch (error) {
    alert(error.message || 'تعذر إنشاء النسخة الاحتياطية.');
  }
}

async function restoreData(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  try {
    if (file.size > BACKUP_MAX_BYTES) throw new Error('حجم النسخة الاحتياطية أكبر من 20 ميجابايت.');
    const rawText = await file.text();
    const checked = await validateBackup(rawText);
    if (!checked.ok) throw new Error(checked.error);
    if (!confirm(`تم التحقق من النسخة (${checked.appVersion}). سيتم استبدال بيانات التطبيق الحالية. هل تريد المتابعة؟`)) return;
    const result = await restoreBackup(rawText);
    if (!result.success) throw new Error(result.error);
    alert('✅ تمت استعادة البيانات والتحقق منها بنجاح. سيعاد تحميل التطبيق الآن.');
    location.reload();
  } catch (error) {
    alert(error.message || 'تعذرت استعادة النسخة الاحتياطية.');
  } finally {
    event.target.value = '';
  }
}
function resetApp(){
  if(!confirm('⚠️ سيتم حذف كل البيانات نهائيًا. متأكد؟')) return;
  if(!confirm('تأكيد أخير: حذف كل شيء؟')) return;
  localStorage.clear();
  alert('✅ تم إعادة الضبط');
  location.reload();
}

/* ===== تغيير طريقة الحساب ===== */
function changeCalcMethod(){
  settings.calcMethod = document.getElementById('calcMethod').value;
  localStorage.setItem('rihlati_settings', JSON.stringify(settings));
  if(currentLoc) fetchPrayerTimes(currentLoc);
}

/* ===== PWA ===== */
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', e=>{
  e.preventDefault(); deferredPrompt = e;
  const banner = document.getElementById('installBanner');
  if(banner) banner.classList.add('show');
});
function installApp(){
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  deferredPrompt.userChoice.then(r=>{
    if(r.outcome === 'accepted') document.getElementById('installBanner').classList.remove('show');
    deferredPrompt = null;
  });
}
// تفعيل العمل بدون إنترنت (PWA)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .then(registration => {
        console.log('PWA Service Worker Active:', registration.scope);
      })
      .catch(err => console.log('SW Error:', err));
  });
}

/* ===== دالة init ===== */
function initIbadat(){ renderPrayerTasks(); renderAdhkarTabs(); renderAdhkarList(); }

/* ===== الإقلاع ===== */
(async function init(){
  initAdhanSounds();
  const calcEl = document.getElementById('calcMethod');
  if(calcEl) calcEl.value = settings.calcMethod;
  const notifEl = document.getElementById('notificationsToggle');
  if(notifEl) notifEl.checked = settings.notifications;
  const prePrayerEl = document.getElementById('prePrayerToggle');
  if(prePrayerEl) prePrayerEl.checked = !!settings.prePrayerReminder;
  const darkEl = document.getElementById('darkToggle');
  if(darkEl) darkEl.checked = settings.darkMode;
  renderPrayerTasks();
  renderAdhkarTabs();
  renderAdhkarList();
  renderAllahNames();
  renderBadges();
  renderNotes();
  renderMonthlyStats();
  renderStats();
  renderHistory();
  renderDailyDua();
  renderDailyAyah();
  renderTasks();
  renderHabits();
  renderGoals();
  updateTreeSummary();
  startWelcomeRotation();
  const loc = await getUserLocation();
  await fetchPrayerTimes(loc);
  updateHomeSummary();
  initQibla();
})();

/* ===== حاسبة الزكاة ===== */
function calculateZakat(){
  const readAmount = id => {
    const el=document.getElementById(id);
    const value=el ? Number(el.value || 0) : 0;
    return Number.isFinite(value) ? value : NaN;
  };

  const cash=readAmount('zakatCash');
  const goldGrams=readAmount('zakatGold');
  const goldPrice=readAmount('zakatGoldPrice');
  const silverGrams=readAmount('zakatSilver');
  const silverPrice=readAmount('zakatSilverPrice');
  const invest=readAmount('zakatInvest');
  const debts=readAmount('zakatDebts');
  const result=document.getElementById('zakatResult');
  if(!result) return;

  const values=[cash,goldGrams,goldPrice,silverGrams,silverPrice,invest,debts];
  if(values.some(v=>!Number.isFinite(v) || v<0)){
    result.textContent='من فضلك أدخل أرقامًا صحيحة غير سالبة في جميع الخانات.';
    return;
  }

  if((goldGrams>0 && goldPrice<=0) || (silverGrams>0 && silverPrice<=0)){
    result.textContent='أدخل سعر جرام الذهب أو الفضة إذا كنت تملك منهما.';
    return;
  }
  if(goldPrice<=0){
    result.textContent='أدخل سعر جرام الذهب لتحديد قيمة النصاب.';
    return;
  }

  const goldValue=goldGrams*goldPrice;
  const silverValue=silverGrams*silverPrice;
  const totalAssets=cash+goldValue+silverValue+invest;
  const netWorth=Math.max(0,totalAssets-debts);
  const nisab=85*goldPrice;
  const money=n=>n.toLocaleString('ar-EG',{minimumFractionDigits:2,maximumFractionDigits:2});

  if(netWorth<nisab){
    result.innerHTML=`
      <div class="card" style="text-align:center;border-right:4px solid var(--muted);">
        <div style="font-size:38px;margin-bottom:8px;">💡</div>
        <div style="font-size:16px;font-weight:700;color:var(--muted);margin-bottom:8px;">صافي المال أقل من النصاب</div>
        <div style="font-size:13px;color:var(--muted);line-height:1.9;">
          إجمالي الأصول: <strong>${money(totalAssets)}</strong> ج.م<br>
          الديون المخصومة: <strong>${money(debts)}</strong> ج.م<br>
          صافي المال: <strong>${money(netWorth)}</strong> ج.م<br>
          النصاب (قيمة 85 جرام ذهب): <strong>${money(nisab)}</strong> ج.م<br>
          لا يبلغ المبلغ المدخل النصاب وفق المعيار المستخدم في هذه الحاسبة.
        </div>
      </div>`;
    return;
  }

  const zakatAmount=netWorth*0.025;
  result.innerHTML=`
    <div class="card" style="text-align:center;background:linear-gradient(135deg,var(--green),#3F9C87);color:white;padding:24px;">
      <div style="font-size:14px;opacity:.9;margin-bottom:8px;">💰 قيمة الزكاة التقديرية</div>
      <div style="font-size:36px;font-weight:700;margin-bottom:6px;">${money(zakatAmount)}</div>
      <div style="font-size:14px;opacity:.9;">جنيه مصري</div>
      <div style="margin-top:16px;padding-top:16px;border-top:1px solid rgba(255,255,255,.3);font-size:13px;line-height:1.9;text-align:right;">
        <div>قيمة الذهب: <strong>${money(goldValue)}</strong> ج.م</div>
        <div>قيمة الفضة: <strong>${money(silverValue)}</strong> ج.م</div>
        <div>النقود والاستثمارات: <strong>${money(cash+invest)}</strong> ج.م</div>
        <div>الديون المخصومة: <strong>${money(debts)}</strong> ج.م</div>
        <div>صافي المال: <strong>${money(netWorth)}</strong> ج.م</div>
        <div>النصاب: <strong>${money(nisab)}</strong> ج.م</div>
        <div>النسبة الحسابية: <strong>2.5%</strong></div>
      </div>
    </div>
    <div class="card" style="margin-top:10px;font-size:12px;color:var(--muted);line-height:1.8;">
      ⚠️ النتيجة تقديرية، وتفترض انطباق شروط الزكاة على الأصول المدخلة ومرور حول هجري. تختلف أحكام زكاة الحلي والاستثمارات والديون بحسب الحالة والفتوى المتبعة.
    </div>`;
}


;

const _wc = document.getElementById('welcomeCard');
if(_wc) _wc.classList.remove('flipped');

;
document.addEventListener("DOMContentLoaded",function(){const rights=document.querySelector(".brand-rights");const home=document.getElementById("screen-home");if(rights&&home)home.appendChild(rights);});