/* رحلة الإيمان — Service Worker V13 */
const APP_CACHE = 'rihla-app-v14-0';
const API_CACHE = 'rihla-api-v13';
// الاسم القديم مستخدم بالفعل في الإصدارات المنشورة؛ نحتفظ به حتى لا نفقد تنزيلات القرآن.
const QURAN_CACHE = 'rihlati-quran';
const QURAN_CACHE_PREFIXES = ['rihlati-quran-', 'rihla-quran-'];
const APP_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './assets/samymedo-rights.png'
];

function isPreservedQuranCache(name) {
  return name === QURAN_CACHE || QURAN_CACHE_PREFIXES.some(prefix => name.startsWith(prefix));
}

function isQuranRequest(url) {
  return (
    (url.hostname === 'alquran.cloud' || url.hostname.endsWith('.alquran.cloud')) &&
    (url.pathname.includes('/v1/surah') || url.pathname.includes('/quran/'))
  ) || url.pathname.endsWith('.quran.json');
}

function isApiRequest(url) {
  return url.hostname === 'api.aladhan.com' || url.hostname.endsWith('.aladhan.com');
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(APP_CACHE);
    await cache.addAll(APP_ASSETS);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    const obsolete = names.filter(name => {
      if (isPreservedQuranCache(name)) return false;
      if (name === APP_CACHE || name === API_CACHE) return false;
      return (
        name.startsWith('rihla-app-') ||
        name.startsWith('rihla-api-') ||
        name.startsWith('rihlati-v10-pwa-') ||
        name.startsWith('rihlati-v10-api-')
      );
    });
    await Promise.all(obsolete.map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

async function cacheFirst(request, cacheName, offlineMessage) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response && response.ok && response.type !== 'opaque') {
      try { await cache.put(request, response.clone()); }
      catch (error) { console.warn('Cache write failed:', error); }
    }
    return response;
  } catch (error) {
    return new Response(offlineMessage, {
      status: 503,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' }
    });
  }
}

async function networkFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  try {
    const response = await fetch(request);
    if (response && response.ok && response.type !== 'opaque') {
      try { await cache.put(request, response.clone()); }
      catch (error) { console.warn('API cache write failed:', error); }
    }
    return response;
  } catch (error) {
    const cached = await cache.match(request);
    if (cached) return cached;
    return new Response(
      JSON.stringify({ error: 'تعذر الاتصال بالإنترنت ولا توجد بيانات محفوظة لهذا الطلب.' }),
      { status: 503, headers: { 'Content-Type': 'application/json; charset=utf-8' } }
    );
  }
}

async function handleAppRequest(request) {
  const cache = await caches.open(APP_CACHE);
  const cached = await cache.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response && response.ok && response.type !== 'opaque') {
      try { await cache.put(request, response.clone()); }
      catch (error) { console.warn('App cache write failed:', error); }
    }
    return response;
  } catch (error) {
    if (request.mode === 'navigate') {
      const fallback = await cache.match('./index.html');
      if (fallback) return fallback;
    }
    return new Response('غير متصل بالإنترنت', {
      status: 503,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' }
    });
  }
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;

  if (isQuranRequest(url)) {
    event.respondWith(cacheFirst(
      request,
      QURAN_CACHE,
      JSON.stringify({ error: 'بيانات هذه السورة غير محفوظة. اتصل بالإنترنت لتنزيلها.' })
    ));
    return;
  }

  if (isApiRequest(url)) {
    event.respondWith(networkFirst(request, API_CACHE));
    return;
  }

  if (url.origin === self.location.origin) {
    event.respondWith(handleAppRequest(request));
  }
});

// فتح التطبيق عند الضغط على إشعار الصلاة.
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({type:'window', includeUncontrolled:true});
    for (const client of windows) {
      if ('focus' in client) return client.focus();
    }
    if (self.clients.openWindow) return self.clients.openWindow('./');
  })());
});
